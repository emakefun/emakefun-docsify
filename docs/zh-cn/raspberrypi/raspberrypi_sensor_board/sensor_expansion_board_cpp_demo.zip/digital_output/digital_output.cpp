#include <iostream>
#include <chrono>
#include <thread>
#include "gpio_expansion_board.h"

 // 创建 GpioExpansionBoard 实例
GpioExpansionBoard gpio_expansion_board;

int main() {
    std::cout << "Setup" << std::endl;

    // 配置A0为输出模式
    if (!gpio_expansion_board.SetGpioMode(GpioExpansionBoard::kGpioPinE0, 
                                        GpioExpansionBoard::kOutput)) {
        std::cerr << "Failed to set GPIO mode" << std::endl;
        return -1;
    }

    // 主循环
    while (true) {
        // 设置A0的输出高电平
        std::cout << "Setting GPIO A0 to HIGH" << std::endl;
        if (!gpio_expansion_board.SetGpioLevel(GpioExpansionBoard::kGpioPinE0, 1)) {
            std::cerr << "Failed to set GPIO level HIGH" << std::endl;
            return -1;
        }
        
        // 延时100毫秒
        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        // 设置A0的输出低电平
        std::cout << "Setting GPIO A0 to LOW" << std::endl;
        if (!gpio_expansion_board.SetGpioLevel(GpioExpansionBoard::kGpioPinE0, 0)) {
            std::cerr << "Failed to set GPIO level LOW" << std::endl;
            return -1;
        }
        
        // 延时100毫秒
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    // 程序结束前将GPIO设置为低电平
    gpio_expansion_board.SetGpioLevel(GpioExpansionBoard::kGpioPinE0, 0);
    std::cout << "Program terminated" << std::endl;
    return 0;
}