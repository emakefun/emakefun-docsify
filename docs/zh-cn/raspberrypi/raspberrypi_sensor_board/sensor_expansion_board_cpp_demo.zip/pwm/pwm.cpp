#include <iostream>
#include <chrono>
#include <thread>
#include "gpio_expansion_board.h"

// 创建 GpioExpansionBoard 实例
GpioExpansionBoard gpio_expansion_board;

int main() {
    std::cout << "Setup" << std::endl;

    // 配置扩展板pwm频率为50hz
    if (!gpio_expansion_board.SetPwmFrequency(50)) {
        std::cerr << "Failed to set PWM frequency" << std::endl;
        return -1;
    }

    // 配置A1为pwm输出模式
    if (!gpio_expansion_board.SetGpioMode(GpioExpansionBoard::kGpioPinE1, 
                                        GpioExpansionBoard::kPwm)) {
        std::cerr << "Failed to set GPIO mode" << std::endl;
        return -1;
    }

    // 主循环
    while (1) {
        // 设置A1的pwm输出占空比为2048，比值为2048 / 4095 约为 50%
        std::cout << "Setting PWM duty cycle to 50% (2048/4095)" << std::endl;
        if (!gpio_expansion_board.SetPwmDuty(GpioExpansionBoard::kGpioPinE1, 2048)) {
            std::cerr << "Failed to set PWM duty cycle to 2048" << std::endl;
            return -1;
        }

        // 延时1秒
        std::this_thread::sleep_for(std::chrono::seconds(1));

        // 设置A1的pwm输出占空比为1024，比值为1024 / 4095 约为 25%
        std::cout << "Setting PWM duty cycle to 25% (1024/4095)" << std::endl;
        if (!gpio_expansion_board.SetPwmDuty(GpioExpansionBoard::kGpioPinE1, 1024)) {
            std::cerr << "Failed to set PWM duty cycle to 1024" << std::endl;
            return -1;
        }

        // 延时1秒
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    // 程序结束前将PWM占空比设置为0
    gpio_expansion_board.SetPwmDuty(GpioExpansionBoard::kGpioPinE1, 0);
    
    std::cout << "Program terminated" << std::endl;
    return 0;
}