#include <iostream>
#include <chrono>
#include <thread>
#include "gpio_expansion_board.h"

// 创建 GpioExpansionBoard 实例
GpioExpansionBoard gpio_expansion_board;

int main() {
  std::cout << "Setup" << std::endl;

  // 配置A0为ADC模式
  if (!gpio_expansion_board.SetGpioMode(GpioExpansionBoard::kGpioPinE0, GpioExpansionBoard::kAdc)) {
    std::cerr << "Failed to set GPIO mode for A0" << std::endl;
    return -1;
  }

  while (true) {
    // 读取A0的ADC值并打印
    uint16_t adc_value = gpio_expansion_board.GetGpioAdcValue(GpioExpansionBoard::kGpioPinE0);
    std::cout << "ADC value: " << adc_value << std::endl;

    // 延时100毫秒
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }

  return 0;
}