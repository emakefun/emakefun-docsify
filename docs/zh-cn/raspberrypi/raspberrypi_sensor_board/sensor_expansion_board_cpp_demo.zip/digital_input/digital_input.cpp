#include <iostream>
#include <thread>
#include <chrono>
#include "gpio_expansion_board.h"

// 创建 GpioExpansionBoard 实例
GpioExpansionBoard gpio_expansion_board;

int main() {
    std::cout << "setup" << std::endl;

    // 配置A0为输入模式，默认拉低电平
    if (!gpio_expansion_board.SetGpioMode(GpioExpansionBoard::kGpioPinE0, GpioExpansionBoard::kInputPullDown)) {
        std::cerr << "Failed to set GPIO mode for A0" << std::endl;
        return -1;
    }

    while (true) {
        // 读取A0的数字值并打印
        uint8_t digital_value = gpio_expansion_board.GetGpioLevel(GpioExpansionBoard::kGpioPinE0);
        std::cout << "digital value: " << static_cast<int>(digital_value) << std::endl;

        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    return 0;
}
