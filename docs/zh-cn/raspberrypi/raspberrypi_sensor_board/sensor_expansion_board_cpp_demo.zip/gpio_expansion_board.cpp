#include "gpio_expansion_board.h"
#include <wiringPiI2C.h>
#include <wiringPi.h>
#include <iostream>

#define ADDRESS_VERSION (0x00)
#define ADDRESS_IO_MODE (0x01)
#define ADDRESS_ANALOG_VALUES (0x10)
#define ADDRESS_VOLTAGE_VALUES (0x20)
#define ADDRESS_RATIO_VOLTAGE (0x30)
#define ADDRESS_DIGITAL_VALUES (0x40)
#define ADDRESS_PWM_DUTY (0x50)
#define ADDRESS_PWM_FREQUENCY (0x60)

GpioExpansionBoard::GpioExpansionBoard(uint8_t device_i2c_address) : device_i2c_address_(device_i2c_address) {
    fd_ = wiringPiI2CSetup(device_i2c_address);
    if (fd_ == -1) {
        std::cerr << "Failed to initialize I2C communication." << std::endl;
    }
}

bool GpioExpansionBoard::SetGpioMode(GpioExpansionBoard::GpioPin gpio_pin, GpioExpansionBoard::GpioMode mode) {
    if (wiringPiI2CWriteReg8(fd_, ADDRESS_IO_MODE + gpio_pin, mode) == -1) {
        std::cerr << "Error occurred when I2C writing." << std::endl;
        return false;
    }
    return true;
}

bool GpioExpansionBoard::SetGpioLevel(GpioExpansionBoard::GpioPin gpio_pin, uint8_t level) {
    if (wiringPiI2CWriteReg8(fd_, ADDRESS_DIGITAL_VALUES + gpio_pin, level) == -1) {
        return false;
    }
    return true;
}

uint8_t GpioExpansionBoard::GetGpioLevel(GpioExpansionBoard::GpioPin gpio_pin) {
    int value = wiringPiI2CReadReg8(fd_, ADDRESS_DIGITAL_VALUES + gpio_pin);
    if (value == -1) {
        return 0;
    }
    return static_cast<uint8_t>(value);
}

uint16_t GpioExpansionBoard::GetGpioAdcValue(GpioExpansionBoard::GpioPin gpio_pin) {
    uint16_t analog_value = 0;
    analog_value = wiringPiI2CReadReg16(fd_, ADDRESS_ANALOG_VALUES + gpio_pin * sizeof(uint16_t));
    return analog_value;
}

bool GpioExpansionBoard::SetPwmFrequency(uint16_t frequency) {
    if (wiringPiI2CWriteReg16(fd_, ADDRESS_PWM_FREQUENCY, frequency) == -1) {
        return false;
    }
    return true;
}

bool GpioExpansionBoard::SetPwmDuty(GpioPin gpio_pin, uint16_t duty) {
    if (wiringPiI2CWriteReg16(fd_, ADDRESS_PWM_DUTY + gpio_pin * sizeof(duty), duty) == -1) {
        return false;
    }
    return true;
}

bool GpioExpansionBoard::SetServoAngle(GpioPin gpio_pin, float angle) {
    return SetPwmFrequency(50) && SetPwmDuty(gpio_pin, ((angle / 90) + 0.5) / 20 * 4095) && SetGpioMode(gpio_pin, kPwm);
}