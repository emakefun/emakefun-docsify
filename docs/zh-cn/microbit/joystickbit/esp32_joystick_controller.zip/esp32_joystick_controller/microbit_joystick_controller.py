from micropython import const

DEFAULT_I2C_ADDRESS: int = const(0x5A)
JOYSTICK_LEFT_X_REG: int = const(0x10)
JOYSTICK_LEFT_Y_REG: int = const(0x11)
JOYSTICK_RIGHT_X_REG: int = const(0x12)
JOYSTICK_RIGHT_Y_REG: int = const(0x13)

BUTTON_LEFT_REG: int = const(0x22)
BUTTON_RIGHT_REG: int = const(0x23)
JOYSTICK_BUTTON_RIGHT: int = const(0x21)
JOYSTICK_BUTTON_LEFT: int = const(0x20)

class Button_Status:
    """
    Enum for the status of a button.
    """
    JOYSTICK_PRESS_DOWN = 0  
    JOYSTICK_PRESS_UP = 1 
    JOYSTICK_SINGLE_CLICK = 3    
    JOYSTICK_DOUBLE_CLICK = 4
    JOYSTICK_LONG_PRESS_HOLD = 6    
    JOYSTICK_NONE_PRESS = 8     

class JoystickController:
    """
    Driver for the Micro:Bit Joystick Controller.
    """

    

    def __init__(self, i2c,i2c_address=DEFAULT_I2C_ADDRESS):
        """
        Initialize the JoystickController object.

        :param i2c_address: The I2C address of the Joystick Controller.

        """
        self._i2c = i2c
        self._i2c_address = i2c_address
    
    def read_joystick_left_x(self):
        """
        Read the X-axis value of the left joystick.

        :return: The X-axis value of the left joystick.
        """
        return self._i2c.readfrom_mem(self._i2c_address, JOYSTICK_LEFT_X_REG, 1)[0]

    def read_joystick_left_y(self):
        """
        Read the Y-axis value of the left joystick.

        :return: The Y-axis value of the left joystick.
        """
        return self._i2c.readfrom_mem(self._i2c_address, JOYSTICK_LEFT_Y_REG, 1)[0]

    def read_joystick_right_x(self):
        """
        Read the X-axis value of the right joystick.

        :return: The X-axis value of the right joystick.
        """
        return self._i2c.readfrom_mem(self._i2c_address, JOYSTICK_RIGHT_X_REG, 1)[0]

    def read_joystick_right_y(self):
        """
        Read the Y-axis value of the right joystick.

        :return: The Y-axis value of the right joystick.
        """
        return self._i2c.readfrom_mem(self._i2c_address, JOYSTICK_RIGHT_Y_REG, 1)[0]
    
    def get_button_status(self, button):
        """
        Read the status of a button.

        :param button: The button to read the status of.
        :return: The status of the button.
        """
        return self._i2c.readfrom_mem(self._i2c_address, button, 1)[0]