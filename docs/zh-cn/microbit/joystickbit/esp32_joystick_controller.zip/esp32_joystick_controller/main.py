import time
from machine import Pin, I2C
from microbit_joystick_controller import *

i2c = I2C(0, sda=Pin(23), scl=Pin(22))

# create a JoystickController object
joystick = JoystickController(i2c=i2c)

while True:
    # read the joystick values
    joystick_left_x = joystick.read_joystick_left_x()
    joystick_left_y = joystick.read_joystick_left_y()
    joystick_right_x = joystick.read_joystick_right_x()
    joystick_right_y = joystick.read_joystick_right_y()

    # print the joystick values
    # print("Left joystick: x = {}, y = {}".format(joystick_left_x, joystick_left_y))
    # print("Right joystick: x = {}, y = {}".format(joystick_right_x, joystick_right_y))

    # check if the right button is pressed
    # if joystick.get_button_status(JOYSTICK_BUTTON_RIGHT) == Button_Status.JOYSTICK_PRESS_DOWN:

    # check if the right button is single clicked
    if (
        joystick.get_button_status(JOYSTICK_BUTTON_RIGHT)
        == Button_Status.JOYSTICK_SINGLE_CLICK
    ):
        print("Joystick right button single click")
        time.sleep_ms(30)

    # check if the right button is double clicked
    if (
        joystick.get_button_status(JOYSTICK_BUTTON_RIGHT)
        == Button_Status.JOYSTICK_DOUBLE_CLICK
    ):
        print("Joystick right button double click")
        time.sleep_ms(30)
