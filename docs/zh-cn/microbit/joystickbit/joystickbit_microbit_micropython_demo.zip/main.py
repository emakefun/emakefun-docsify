from time import sleep
from microbit import *
from microbit_joystick_controller import *

# create a JoystickController object
joystick = JoystickController()

while True:
    # read the joystick values
    joystick_left_x = joystick.read_joystick_left_x()
    joystick_left_y = joystick.read_joystick_left_y()
    joystick_right_x = joystick.read_joystick_right_x()
    joystick_right_y = joystick.read_joystick_right_y()

    # print the joystick values
    # print("Left joystick: x = {}, y = {}".format(joystick_left_x, joystick_left_y))
    # print("Right joystick: x = {}, y = {}".format(joystick_right_x, joystick_right_y))

    # check if the right button is pressed
    # if joystick.get_button_status(JOYSTICK_BUTTON_RIGHT) == Button_Status.JOYSTICK_PRESS_DOWN:
    #     print("Joystick right button pressed")

    # check if the right button is single clicked
    if joystick.get_button_status(JOYSTICK_BUTTON_RIGHT) == Button_Status.JOYSTICK_SINGLE_CLICK:
        print("Joystick right button single click")
        sleep(30);
    
    # check if the right button is double clicked
    if joystick.get_button_status(JOYSTICK_BUTTON_RIGHT) == Button_Status.JOYSTICK_DOUBLE_CLICK:
        print("Joystick right button double click")
        sleep(30);
