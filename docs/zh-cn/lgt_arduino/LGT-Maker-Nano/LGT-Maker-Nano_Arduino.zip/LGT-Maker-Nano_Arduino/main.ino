#include <Arduino.h>

// ===================== 电机引脚 =====================
// 6、7 接一个 TT 马达
const int MOTOR_PIN_A = 6;
const int MOTOR_PIN_B = 7;

// ===================== 运行参数 =====================
const unsigned long MOTOR_RUN_MS = 1000;  // 每个方向运行时间 ms

// ===================== 全局变量 =====================
unsigned int cycleCount = 0;   // 完成一次正反转循环的计数

// ===================== 函数前置声明 =====================
void motorForward();
void motorReverse();
void motorStop();

// =====================================================
// setup
// =====================================================
void setup() {
  // --- 串口初始化 ---
  Serial.begin(9600);
  delay(200);
  Serial.println(F("=== LGT8F328P TT Motor ==="));

  // --- 电机引脚初始化 ---
  pinMode(MOTOR_PIN_A, OUTPUT);
  pinMode(MOTOR_PIN_B, OUTPUT);
  motorStop();

  Serial.println(F("[INIT] Ready. Entering main loop."));
}

// =====================================================
// loop：正转 1s -> 立即反转 1s -> 计数
// =====================================================
void loop() {
  // ---- 马达正转 1s ----
  Serial.println(F("[LOOP] Forward"));
  motorForward();
  delay(MOTOR_RUN_MS);

  // ---- 立即反转（无停止间隔）----
  Serial.println(F("[LOOP] Reverse"));
  motorReverse();
  delay(MOTOR_RUN_MS);

  // ---- 完成一次正反转循环 ----
  cycleCount++;

  Serial.print(F("[LOOP] Cycle = "));
  Serial.println(cycleCount);
}

// =====================================================
// 电机控制函数
// =====================================================
void motorForward() {
  // 先拉低 B 端，再拉高 A 端，避免换向瞬间同时为高
  digitalWrite(MOTOR_PIN_B, LOW);
  digitalWrite(MOTOR_PIN_A, HIGH);
}

void motorReverse() {
  // 先拉低 A 端，再拉高 B 端，避免换向瞬间同时为高
  digitalWrite(MOTOR_PIN_A, LOW);
  digitalWrite(MOTOR_PIN_B, HIGH);
}

void motorStop() {
  digitalWrite(MOTOR_PIN_A, LOW);
  digitalWrite(MOTOR_PIN_B, LOW);
}