# 使用 MicroPython 驱动编码电机与直流电机

> 适用开发板：MAKER-ESP32-PRO  
> 运行环境：MicroPython ≥ 1.29（ESP32 端口）  
> 配套库：`encoder_motor.py`

本文以「第一次把电机转起来」为目标，从接线走到闭环调速，每一步都给出可观察的现象。如果你只想驱动一个不带编码器的直流电机，可以直接跳到第 6 节。

## 1.1 MAKER-ESP32-PRO 使用说明书

### 模块实物图

![](images/fig-01.png)

### 概述

MAKER-ESP32-PRO是基于乐鑫科技的 **ESP32-WROOM-32** 模组基础上开发的一款适用于创客教育的标志性产品，Flash大小4MB，集成 2.4 GHz、Wi-Fi 和蓝牙双模的单芯片方案。板载4路编码电机和直流电机，最大驱动电流3A，编码电机和直流电机复用驱动引脚，即同一个端口，不能同时驱动编码电机和直流电机。

### ESP32模组参数

448 KB ROM,520 KB SRAM,16 KB RTC SRAM

QSPI 支持多个 flash/SRAM

内置 8 MHz 振荡器

支持自校准

内置 RC 振荡器，支持自校准

支持外置 2 MHz 至 60 MHz 的主晶振（如果使用 Wi-Fi/蓝牙功能，则目前仅支持 40 MHz 晶振）

支持外置 32 kHz 晶振，用于 RTC，支持自校准

2 个定时器群组，每组包括 2 个 64-bit 通用定时器和 1 个主系统看门狗

1 个 RTC 定时器

RTC 看门狗

34 个 GPIO 口 • 12-bit SAR ADC，多达 18 个通道

带有专用 DMA 的以太网 MAC 接口，支持 IEEE 1588

双线汽车接口（TWAI®，兼容 ISO11898-1） • IR (TX/RX)

### 产品参数

4个编码电机端口（E0、E1、E2、E3）；4个直流电机端口（M0、M1、M2、M3）端口与编码电机复用；电流最大达到3A

其中E0(A:18 B:19 +:27 -:13)，E1(A:5 B:23 +:4 -:2)，E2(A:35 B:36 +:17 -:12)，E3(A:34 B:39 +:15 -:14)

5个I2C插针接口,1个SPI插针接口

4个舵机接口（25、26、32、33）

13个IO引脚(5、12、14、15、16、17、18、19、23、34、35、36、39)

输入电压： 6-16V

产品尺寸：80mm×57mm；PCB厚度：1.6mm；净重：35g

M4定位孔直径：4.6mm，兼容乐高

软件支持Mixly、Arduino IDE、MicroPython

### 引脚说明

![](images/fig-02.png)

## 1.2 软件清单

| 软件 | 用途 |
|---|---|
| Thonny 4.x | 编辑、运行、看串口输出（推荐） |
| 或 mpremote | 命令行上传与运行 |

Thonny 首次连接需要选解释器：`运行 → 配置解释器 → MicroPython (ESP32) → 端口选 COMx → ``安装官方固件`。

![](images/fig-03.png)

## 1.3 确认固件版本

在 Thonny 的 Shell 里输入：

```
import sys
print(sys.implementation.version)
```

输出应类似 `(1, 29, 0, '')`。

**这个版本号很关键**：`1.29` 起才有 `machine.Encoder`（PCNT 硬件正交解码）。低于 1.29 时库会自动退回软件中断解码，功能能跑，但高速下方向判断不可靠。

如果版本过低，用乐鑫官方工具重刷固件后再继续。

## 2. 接线

![](images/fig-04.jpeg)

### 2.1 编码电机

把编码电机的 **6 芯插头**插到板子上标有 `E0` 的插座：

| 板上丝印 | 引脚 | 接到 |
|---|---|---|
| `+` | GPIO27 | 电机正极 |
| `−` | GPIO13 | 电机负极 |
| `A` | GPIO18 | 编码器 A 相 |
| `B` | GPIO19 | 编码器 B 相 |

![](images/fig-05.jpeg)

插头有防呆结构，插不进时**换个方向**，不要硬插。

### 2.2 直流电机（可选）

不带编码器的电机插到 `M1` 的 **2 芯**插座，引脚是 GPIO4(+) / GPIO2(−)。
> `E1` 和 `M1` 是**同一路**驱动的两个插座，二选一，不能同时接。

### 2.3 连接电脑

Type-C 线接电脑，Thonny 右下角能看到 `MicroPython (ESP32) · COMx` 即为连接成功。

## 3. 把库放到板子上

库只有**一个文件**：`encoder_motor.py`。

### 3.1 方法一：Thonny 拖拽（推荐）

1. 打开 Thonny，选择 `视图 → 文件`，左侧出现「本机」和「MicroPython 设备」两栏；
2. 在本机找到 `lib/encoder_motor.py`；
3. 右键 → `上传到 /`，或直接拖到右侧设备栏；
4. 设备栏出现 `encoder_motor.py` 即成功。

![](images/fig-06.png)

![](images/fig-07.png)

### 3.2 方法二：mpremote

```
mpremote fs cp lib/encoder_motor.py :encoder_motor.py
```

### 3.3 验证

在 Shell 里：

```
import encoder_motor as em
print(em.__version__)
```

输出 `0.2.0` 即部署成功。

![](images/fig-08.png)

i

## 4. 示例一：检测相位关系

编码器的 A、B 两相谁领先谁，取决于电机型号和接线方式。**这一步不做，后面的闭环可能会飞车。**

### 4.1 打开示例

在 Thonny 中打开 `examples/detect_phase_relation/main.py`，按 **F5** 运行。

（不用先把文件拷到板子上——Thonny 会把当前文件直接送到板子上执行，库已经在板子里。）

### 4.2 第一次运行：看到负值

```
example version: 1.0.0 lib version: 0.2.0
pins: POS=27 NEG=13 A=18 B=19
speed with +1023: -87 RPM, pulses: -2231
PHASE: B_PHASE_LEADS is required, switching at runtime ...
set_phase() -> True  speed now: 83 RPM (pulses keep counting, no reset)
motor shut down
```

![](images/fig-09.png)

**现象解读**：我们给的是正占空比，电机在正转，但转速读数是负的——说明相位参数填反了。

### 4.3 让参数生效

示例里已经演示了运行期切换：

```
ok = motor.set_phase(em.PHASE_RELATION_B_PHASE_LEADS)
```

返回 `True` 表示切换成功，之后的读数立刻变正，**而且计数不会归零**。

如果要在工程代码里固定下来，直接在构造函数里写：

```
m = em.EncoderMotor(27, 13, 18, 19, 12, 90,
                    em.PHASE_RELATION_B_PHASE_LEADS)   # ← 这一项
```

![](images/fig-10.png)

> 换电机、换通道后都需要重做这一步。库的默认值是 `A_PHASE_LEADS`（与 Arduino 原库一致），  
> 这块板上的电机通常是 `B_PHASE_LEADS`。

### 4.4 调速度：改 main.py 里的目标转速

检测完相位后，把 examples/motor_test/main.py 拷到板子上运行（或在 Thonny 里直接按 F5）。要改速度，就改文件里 run_speed() 括号里的数字：

```
motor.run_speed(50)      # 目标 50 RPM
motor.run_speed(80)      # 改成 80 RPM
motor.run_speed(-30)     # 负数 = 反转
```

![](images/fig-11.png)

![](images/fig-12.png)

括号里填的是转速（RPM），不是占空比。控制器会自动调整占空比去逼近这个值，电压下降或负载变化时也会自动补回来。

可用范围：约 10 ~ 110 RPM（7.4 V 供电）、10 ~ 190 RPM（12 V 供电）。设为 0 或绝对值小于 10 会直接停机。

如果只想给固定电压、不要闭环，把 run_speed() 换成 run_pwm_duty()：

```
motor.run_pwm_duty(600)  # 60% 占空比，开环
```

注意占空比低于约 150~200 时电机不会转（死区），调试时别设太小。

## 5. 常见问题

### Q1：程序跑起来了，电机不转

按顺序检查：
1. **DC 电源是否接上、开关是否 ON**（最常见）
2. **Motor/IO 拨码是否在 M 侧**
3. 电机线是否插到位，E0 的 6 芯插头有没有插反
4. 程序里的引脚号是否和实际通道一致

### Q2：电机转了，但 `pulses` 一直是 0

编码器信号没进来：
1. 插头是否插到底
2. A/B 两根线是否接反（接反只会导致方向相反，不会导致 0）
3. 用万用表量一下编码器的 5 V 供电是否正常

如果 `pulses` 偶尔跳几个数但不连续，通常是插头接触不良。

### Q3：`ImportError: no module named 'encoder_motor'`

库没放到板子上，或者放到了子目录。**必须放在板子根目录**（`/encoder_motor.py`）。

### Q4：闭环时电机猛转、占空比冲到 1023

相位参数配反了，PID 变成正反馈。回到第 4 节重新检测相位。

**这是最危险的一种**——轮子着地时会飞车，调试时务必架空。

### Q5：`RuntimeError: no free hardware timer`

板上有其他库也占用了硬件定时器。调用 `em.use_timer(False)` 关掉自动调度，改在主循环里手动调 `m.update()`。
