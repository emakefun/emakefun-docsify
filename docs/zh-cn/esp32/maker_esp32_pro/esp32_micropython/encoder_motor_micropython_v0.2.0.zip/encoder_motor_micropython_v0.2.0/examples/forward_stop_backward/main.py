"""Example: forward -> stop -> backward state machine (closed loop).

Runs one cycle (finite) and always shuts the motor down at the end.
"""
import time

import encoder_motor as em

print("lib version:", em.__version__)

# 板级接线由使用方指定，库本身不含任何引脚定义
POSITIVE_PIN = 27
NEGATIVE_PIN = 13
ENCODER_A_PIN = 18
ENCODER_B_PIN = 19
PPR = 12
REDUCTION_RATIO = 90
PHASE_RELATION = em.PHASE_RELATION_B_PHASE_LEADS   # 本板电机为 B 相领先

motor = em.EncoderMotor(POSITIVE_PIN, NEGATIVE_PIN, ENCODER_A_PIN, ENCODER_B_PIN,
                        PPR, REDUCTION_RATIO, PHASE_RELATION)
motor.init()
try:
    for name, target in (("FORWARD", 100), ("STOP", 0), ("BACKWARD", -100)):
        print("---", name, "target", target, "RPM ---")
        if target == 0:
            motor.stop()
        else:
            motor.run_speed(target)

        t0 = time.ticks_ms()
        last = 0
        while time.ticks_diff(time.ticks_ms(), t0) < 1500:
            elapsed = time.ticks_diff(time.ticks_ms(), t0)
            if elapsed - last >= 300:
                last = elapsed
                print("t=%4d ms speed=%5d RPM pwm_duty=%5d pulses=%7d"
                      % (elapsed, motor.speed, motor.pwm_duty, motor.pulse_count))
            time.sleep_ms(5)
finally:
    motor.stop()
    motor.deinit()
    print("motor shut down")
