"""Example: drive a DC motor with the bare Motor class (no encoder needed).

Forward -> brake -> backward -> brake -> coast. Finite and self-stopping.
"""
import time

import encoder_motor as em

print("lib version:", em.__version__)

# 板级接线由使用方指定，库本身不含任何引脚定义
POSITIVE_PIN = 27
NEGATIVE_PIN = 13

motor = em.Motor(POSITIVE_PIN, NEGATIVE_PIN)
motor.init()
try:
    motor.run_pwm_duty(1023)
    print("forward,  pwm_duty =", motor.pwm_duty)
    time.sleep_ms(1000)

    motor.stop()
    print("brake,    pwm_duty =", motor.pwm_duty, "(两脚拉高，短路制动)")
    time.sleep_ms(300)

    motor.run_pwm_duty(-1023)
    print("backward, pwm_duty =", motor.pwm_duty)
    time.sleep_ms(1000)

    motor.stop()
    print("brake,    pwm_duty =", motor.pwm_duty)
    time.sleep_ms(300)

    motor.coast()
    print("coast,    pwm_duty =", motor.pwm_duty, "(两脚输出 0，自由滑行)")
    time.sleep_ms(500)
finally:
    motor.deinit()          # 两脚拉低，无驱动电流
    print("motor shut down")
