"""multi_test.py — 双路并行 / 电源耦合 / 资源分配

接线：E0 = 编码电机(6芯)，M1 = 无编码器电机(2芯)，E2/E3 空置。
"""
import time
import encoder_motor as em

cfg = em.BOARD_MAKER_ESP32_PRO

# ch0：编码电机，闭环
m0 = em.EncoderMotor(*cfg[0], 12, 90, em.PHASE_RELATION_B_PHASE_LEADS)
m0.init()
# ch1：无编码器直流电机，只用 Motor 类开环
d1 = em.Motor(cfg[1][0], cfg[1][1])
d1.init()

print("ch0 decoder=%s pcnt=%s | ch1 开环 Motor(%d,%d)"
      % (m0.decoder, m0.encoder_id, cfg[1][0], cfg[1][1]))

def hold(seconds, tag):
    """让 ch0 保持 50 RPM，同时按 tag 给 ch1 不同负载，返回 ch0 的占空比区间。"""
    lo, hi, n = 9999, -9999, 0
    t0 = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), t0) < seconds * 1000:
        time.sleep_ms(250)
        s = m0.speed
        if s < lo:
            lo = s
        if s > hi:
            hi = s
        n += 1
    print("  %-14s ch0: speed %d~%d  duty=%d  ch1_duty=%d"
          % (tag, lo, hi, m0.pwm_duty, d1.pwm_duty))
    return m0.pwm_duty

print("\n[A] 干扰测试：ch0 恒 50 RPM，ch1 依次空载 / 全速正 / 全速反")
m0.run_speed(50)
time.sleep_ms(1500)
d1.run_pwm_duty(0)
base = hold(3, "ch1 空载")
d1.run_pwm_duty(1000)
fwd = hold(3, "ch1 全速正")
d1.run_pwm_duty(-1000)
rev = hold(3, "ch1 全速反")
d1.run_pwm_duty(0)
print("  电源耦合评估：满载时 ch0 占空比 %d -> %d（增加 %d）"
      % (base, max(fwd, rev), max(fwd, rev) - base))

print("\n[B] 资源分配：再空建 ch2/ch3（不接电机）")
extra = []
for ch in (2, 3):
    try:
        x = em.EncoderMotor(*cfg[ch])
        x.init()
        extra.append(x)
        print("  ch%d init OK  pcnt=%s  decoder=%s" % (ch, x.encoder_id, x.decoder))
    except Exception as e:
        print("  ch%d FAIL -> %s: %s" % (ch, type(e).__name__, e))
print("  已分配 PCNT 单元:", sorted(em._HW_IDS))
print("  存活实例数:", len(em._instances), " 定时器:", em._tick_timer is not None)

print("\n[C] 四实例同时受控 3 秒")
m0.run_speed(50)
for i, x in enumerate(extra):
    x.run_speed(20 if i == 0 else -20)
for i in range(6):
    time.sleep_ms(500)
    print("  t=%.1f ch0=%4d ch2=%4d ch3=%4d"
          % ((i + 1) * 0.5, m0.speed, extra[0].speed, extra[1].speed))

print("\n[D] 清理")
m0.stop(); d1.stop()
for x in extra:
    x.deinit()
m0.deinit(); d1.deinit()
print("  存活实例=%d 定时器=%s PCNT单元=%s"
      % (len(em._instances), em._tick_timer, sorted(em._HW_IDS)))
print("MULTI DONE")
