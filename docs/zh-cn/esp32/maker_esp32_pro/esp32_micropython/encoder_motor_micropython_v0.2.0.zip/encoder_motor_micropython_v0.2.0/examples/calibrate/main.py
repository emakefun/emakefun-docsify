"""calibrate.py — 双向标定：扫描正/反占空比-转速，拟合并写入 calib.json

用法：
    import calibrate

换电池、换电机、改供电电压后重跑一次即可。结果写入板内 calib.json，
启动时用 em.load_calib(通道号) + m.apply_calib(d) 加载。
"""

import time
import json
import encoder_motor as em

CH = 0
SWEEP = (560, 640, 720, 800, 880, 950, 1023)

cfg = em.BOARD_MAKER_ESP32_PRO[CH]
m = em.EncoderMotor(cfg[0], cfg[1], cfg[2], cfg[3],
                    ppr=12, reduction=90, period_ms=50)

def spin(ms):
    t0 = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), t0) < ms:
        m.update()
        time.sleep_ms(5)

def fit(pts):
    """pts: [(duty, rpm)]，返回 (bias, slope)，满足 duty ≈ bias + slope*rpm。"""
    n = len(pts)
    sx = sy = sxx = sxy = 0.0
    for x, y in pts:
        sx += x
        sy += y
        sxx += x * x
        sxy += x * y
    a = (n * sxy - sx * sy) / (n * sxx - sx * sx)
    b = (sy - a * sx) / n
    return -b / a, 1.0 / a

m.init()
m.stop(brake=False)
spin(300)
print("CAL START ch=%d" % CH)

# 1) 相位
m.run_pwm(1023)
spin(1300)
phase = em.A_PHASE_LEADS
if m.rpm < 0:
    phase = em.B_PHASE_LEADS
m.set_phase(phase)
spin(900)
print("phase=%s  rpm=%d" % ("B" if phase else "A", m.rpm))

# 2) 正向
fwd = []
for d in SWEEP:
    if d > 1000:
        d = 1000
    m.run_pwm(d)
    spin(1200)
    print("F %4d  rpm=%4d" % (d, m.rpm))
    if m.rpm > 4:
        fwd.append((d, m.rpm))

# 3) 反向
rev = []
for d in SWEEP:
    if d > 900:
        d = 900           # 超过 -900 会出现自举衰减，标定区间只到 900
    m.run_pwm(-d)
    spin(1200)
    print("R %4d  rpm=%4d" % (-d, m.rpm))
    if m.rpm < -4:
        rev.append((d, -m.rpm))

m.stop()

if len(fwd) < 2 or len(rev) < 2:
    print("!! 有效点不足，标定失败。检查供电与接线。")
else:
    bp, sp = fit(fwd)
    bn, sn = fit(rev)
    rec = {
        "phase": phase,
        "bias_pos": round(bp), "slope_pos": round(sp, 2),
        "bias_neg": round(bn), "slope_neg": round(sn, 2),
    }
    print("FWD  duty = %d + %.2f * rpm" % (rec["bias_pos"], rec["slope_pos"]))
    print("REV  duty = %d + %.2f * rpm" % (rec["bias_neg"], rec["slope_neg"]))

    try:
        data = {}
        try:
            with open("calib.json") as f:
                data = json.load(f)
        except Exception:
            data = {}
        data["ch%d" % CH] = rec
        with open("calib.json", "w") as f:
            json.dump(data, f)
        print("SAVED calib.json")
    except Exception as e:
        print("保存失败:", e)

print("CAL DONE")
