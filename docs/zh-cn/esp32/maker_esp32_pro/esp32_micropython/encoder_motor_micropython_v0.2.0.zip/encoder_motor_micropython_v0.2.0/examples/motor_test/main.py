"""
main.py — MAKER-ESP32-PRO 编码电机五步验证（板内文件名建议 motor_test.py）

直接运行即可，全程按串口提示观察。
通过标准：
  步骤0  给满占空比后 rpm 为正（相位正确），约 110 RPM
  步骤1  正反转都能转、停得下
  步骤2  手转输出轴整 1 圈，计数接近 1080
  步骤3  duty=800 时 rpm 稳定在 70 上下
  步骤4  闭环 50 RPM，1 秒内进入 ±5 RPM
"""

import time
import encoder_motor as em

# ------------------ 配置 ------------------

CHANNEL = 0                     # 0=E0/M0, 1=E1/M1, 2=E2/M2, 3=E3/M3
PHASE = em.B_PHASE_LEADS        # 本板 TT 电机实测为 B 相领先（步骤0 会自动校验）
PERIOD_MS = 50
# -----------------------------------------

cfg = em.BOARD_MAKER_ESP32_PRO[CHANNEL]
m = em.EncoderMotor(cfg[0], cfg[1], cfg[2], cfg[3],
                    ppr=12, reduction=90,
                    phase=PHASE, period_ms=PERIOD_MS)

# 有标定文件就用标定值（换电池/换电机后跑一次 calibrate.py 即可）
_cal = em.load_calib(CHANNEL)
if _cal:
    m.apply_calib(_cal)

def spin(ms):
    t0 = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), t0) < ms:
        m.update()
        time.sleep_ms(5)

def main():
    m.init()
    print("=" * 46)
    print("MAKER-ESP32-PRO 编码电机验证  v%s" % em.__version__)
    print("通道 E%d  引脚 (+, -, A, B) = %s" % (CHANNEL, cfg))
    print("每圈计数 = %d  标定=%s  解码=%s"
          % (m.counts_per_rev, "已加载" if _cal else "默认", m.decoder))
    print("前馈 +:%d/%.2f  -:%d/%.2f  上限 +%d/-%d"
          % (m.ff[1][0], m.ff[1][1], m.ff[-1][0], m.ff[-1][1],
             m.duty_max[1], m.duty_max[-1]))
    print("=" * 46)

    # ---- 步骤 0：相位检查（必须用满占空比，否则低速推不动） ----
    print("\n[0/4] 相位检查：duty=1023 跑 2 秒")
    m.run_pwm(1023)
    spin(2000)
    rpm = m.rpm
    print("      rpm=%d" % rpm)
    if abs(rpm) < 5:
        print("      !! 几乎不转：先查 DC 供电(6-16V)、Motor/IO 拨码、电机线")
    elif rpm < 0:
        m.set_phase(em.A_PHASE_LEADS)
        spin(800)
        print("      RPM 为负 -> 相位应为 A_PHASE_LEADS，已修正，现 rpm=%d" % m.rpm)
    else:
        print("      相位正确（B_PHASE_LEADS）")
    m.stop()
    spin(400)

    # ---- 步骤 1：开环正反转 ----
    print("\n[1/4] 开环：+800 -> 0 -> -800 -> 0，各 1 秒")
    for d in (800, 0, -800, 0):
        m.run_pwm(d)
        spin(1000)
        print("      duty=%+5d   rpm=%4d   count=%d" % (d, m.rpm, m.count))
    m.stop()

    # ---- 步骤 2：手转一圈数脉冲 ----
    print("\n[2/4] 计数自检：手转输出轴整 1 圈，10 秒（已切到滑行，转起来很轻）")
    m.stop(brake=False)
    time.sleep_ms(300)
    m.reset_count()
    for i in range(10):
        spin(1000)
        print("      %2ds  count=%d" % (i + 1, m.count))
    c = abs(m.count)
    print("      实测 %d，理论 %d（误差 %.1f%%）"
          % (c, m.counts_per_rev, abs(c - m.counts_per_rev) * 100.0 / m.counts_per_rev))

    # ---- 步骤 3：开环定速测速 ----
    print("\n[3/4] 开环定速：duty=800，4 秒")
    m.run_pwm(800)
    for i in range(8):
        spin(500)
        print("      rpm=%4d  duty=%+5d" % (m.rpm, m.duty))

    # ---- 步骤 4：闭环 ----
    print("\n[4/4] 闭环：目标 50 RPM，8 秒")
    m.run_speed(50)
    err_max = 0
    for i in range(16):
        spin(500)
        e = abs(m.rpm - m.target)
        if i > 1 and e > err_max:
            err_max = e
        print("      target=%3d  rpm=%4d  duty=%+5d  err=%d"
              % (m.target, m.rpm, m.duty, m.rpm - m.target))
    print("      稳态最大误差 ±%d RPM" % err_max)

    print("\n[复查] 反向：目标 -50 RPM，4 秒")
    m.run_speed(-50)
    for i in range(8):
        spin(500)
        print("      target=%3d  rpm=%4d  duty=%+5d" % (m.target, m.rpm, m.duty))

    m.stop()
    print("\n完成。")

try:
    main()
except KeyboardInterrupt:
    pass
finally:
    m.stop()
    print("\n电机已停止。")
