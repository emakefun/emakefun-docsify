"""Example: detect the A/B phase relation of the connected encoder motor.

Runs +1023 briefly starting from the generic A-leads default:
  * speed > 0 -> A phase leads
  * speed < 0 -> B phase leads

Then applies the correct relation at runtime with ``set_phase()`` and re-checks.
运行期切换相位是本移植的扩展（Arduino 版只能在构造函数里指定）。
Finite: always shuts the motor down at the end.
"""
import time

import encoder_motor as em

__version__ = "1.0.0"
print("example version:", __version__, "lib version:", em.__version__)

# 板级接线由使用方指定，库本身不含任何引脚定义
POSITIVE_PIN = 27
NEGATIVE_PIN = 13
ENCODER_A_PIN = 18
ENCODER_B_PIN = 19
PPR = 12
REDUCTION_RATIO = 90

# 故意从通用的 A 相领先默认值开始，让测得的速度符号暴露真实相位
motor = em.EncoderMotor(POSITIVE_PIN, NEGATIVE_PIN, ENCODER_A_PIN, ENCODER_B_PIN,
                        PPR, REDUCTION_RATIO, em.PHASE_RELATION_A_PHASE_LEADS)
motor.init()
print("pins: POS=%d NEG=%d A=%d B=%d"
      % (POSITIVE_PIN, NEGATIVE_PIN, ENCODER_A_PIN, ENCODER_B_PIN))
try:
    motor.run_pwm_duty(1023)
    time.sleep_ms(1200)
    print("speed with +1023:", motor.speed, "RPM, pulses:", motor.pulse_count)

    if motor.speed > 0:
        print("PHASE: A_PHASE_LEADS is correct")
    elif motor.speed < 0:
        print("PHASE: B_PHASE_LEADS is required, switching at runtime ...")
        ok = motor.set_phase(em.PHASE_RELATION_B_PHASE_LEADS)
        time.sleep_ms(1200)
        print("set_phase() ->", ok, " speed now:", motor.speed,
              "RPM (pulses keep counting, no reset)")
    else:
        print("PHASE: inconclusive (motor did not turn)")
finally:
    motor.stop()
    motor.deinit()
    print("motor shut down")
