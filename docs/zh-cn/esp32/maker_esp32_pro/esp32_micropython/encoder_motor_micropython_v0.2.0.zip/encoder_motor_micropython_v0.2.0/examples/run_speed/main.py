"""Example: closed-loop speed control.

Uses the default speed PID (P=3.0, I=1.0, D=1.0; D is stored but not used by
the control law). Finite and self-stopping.
"""
import time

import encoder_motor as em

print("lib version:", em.__version__)

# 板级接线由使用方指定，库本身不含任何引脚定义
POSITIVE_PIN = 27
NEGATIVE_PIN = 13
ENCODER_A_PIN = 18
ENCODER_B_PIN = 19
PPR = 12
REDUCTION_RATIO = 90
PHASE_RELATION = em.PHASE_RELATION_B_PHASE_LEADS   # 本板电机为 B 相领先

motor = em.EncoderMotor(POSITIVE_PIN, NEGATIVE_PIN, ENCODER_A_PIN, ENCODER_B_PIN,
                        PPR, REDUCTION_RATIO, PHASE_RELATION)
motor.init()
print("speed PID:", motor.get_speed_pid())
try:
    for target in (100, -100):
        motor.run_speed(target)

        t0 = time.ticks_ms()
        last = 0
        while time.ticks_diff(time.ticks_ms(), t0) < 1500:
            elapsed = time.ticks_diff(time.ticks_ms(), t0)
            if elapsed - last >= 250:
                last = elapsed
                print("t=%4d ms target=%4d RPM speed=%5d RPM pwm_duty=%5d pulses=%7d"
                      % (elapsed, target, motor.speed, motor.pwm_duty, motor.pulse_count))
            time.sleep_ms(5)

        motor.stop()
        print("STOP after target", target, "pwm_duty =", motor.pwm_duty)
        time.sleep_ms(200)
finally:
    motor.stop()
    motor.deinit()
    print("motor shut down")
