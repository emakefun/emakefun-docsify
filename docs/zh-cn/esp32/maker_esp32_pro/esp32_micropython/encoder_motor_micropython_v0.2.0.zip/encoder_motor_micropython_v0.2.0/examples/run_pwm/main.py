"""Example: read RPM / duty / pulse count while running at fixed PWM duty.

Runs a finite sequence at +1023 and -1023, so the motor is always shut down
afterwards.
"""
import time

import encoder_motor as em

print("lib version:", em.__version__)

# 板级接线由使用方指定，库本身不含任何引脚定义
POSITIVE_PIN = 27
NEGATIVE_PIN = 13
ENCODER_A_PIN = 18
ENCODER_B_PIN = 19
PPR = 12
REDUCTION_RATIO = 90
PHASE_RELATION = em.PHASE_RELATION_B_PHASE_LEADS

motor = em.EncoderMotor(POSITIVE_PIN, NEGATIVE_PIN, ENCODER_A_PIN, ENCODER_B_PIN,
                        PPR, REDUCTION_RATIO, PHASE_RELATION)
motor.init()
print("total_ppr =", motor.total_ppr, " phase_relation =", motor.phase_relation)
try:
    for duty in (1023, -1023):
        motor.reset_pulse_count()
        motor.run_pwm_duty(duty)

        t0 = time.ticks_ms()
        last = 0
        while time.ticks_diff(time.ticks_ms(), t0) < 1200:
            elapsed = time.ticks_diff(time.ticks_ms(), t0)
            if elapsed - last >= 200:
                last = elapsed
                print("t=%4d ms duty=%5d speed=%5d RPM pwm_duty=%5d pulse_count=%7d"
                      % (elapsed, duty, motor.speed, motor.pwm_duty, motor.pulse_count))
            time.sleep_ms(5)

        motor.stop()
        print("STOP duty=%d, pwm_duty=%d, pulses=%d"
              % (duty, motor.pwm_duty, motor.pulse_count))
        time.sleep_ms(200)
finally:
    motor.stop()
    motor.deinit()
    print("motor shut down")
