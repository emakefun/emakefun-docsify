# encoder_motor

ESP32 MicroPython 编码电机驱动库。提供双路 PWM 电机驱动、AB 相正交编码计数、转速测量与
速度闭环控制，所有 I/O 引脚由使用方显式指定，不绑定任何固定通道。

本库是 emakefun `em_esp32_encoder_motor`（Arduino C++ v1.2.0）的 MicroPython 移植，
架构上与官方 MicroPython 版（v2.0.0）保持一致，并额外提供相位自检、多电压标定与异常隔离。

- 版本：`0.2.0`（见模块属性 `__version__`）
- 实现文件：`lib/encoder_motor.py`（单文件，692 行）

---

## 1. 项目简介

| 类 | 适用场景 |
|---|---|
| `Motor` | 只需驱动电机，不读编码器 |
| `EncoderMotor` | 需要转速反馈或速度闭环的编码电机 |

库本身不含任何板级引脚定义，也不预设通道（E0/E1…）与电机参数；引脚、每转脉冲数（PPR）、
减速比、相位关系均由构造参数传入，因此同一份代码可驱动任意通道、任意接线的电机。

多实例并发由库统一管理：每个 `EncoderMotor` 实例占用一个独立的 PCNT 计数单元，所有实例的
转速更新与速度闭环由**同一个 50 ms 硬件定时器**驱动——`init()` 之后即可运行，主循环不需要
做任何事，行为与 C++ 版的后台线程一致。

---

## 2. 目录结构

```
encoder_motor_micropython_v0.2.0/
├── lib/
│   └── encoder_motor.py              ← 库本体（唯一必需文件）
├── examples/
│   ├── detect_phase_relation/main.py ← 检测 A/B 相位关系
│   ├── drive_dc_motor/main.py        ← 只用 Motor 类驱动直流电机
│   ├── forward_stop_backward/main.py ← 闭环 正转→停→反转
│   ├── run_pwm/main.py               ← 固定占空比，观察转速与计数
│   ├── run_speed/main.py             ← 闭环调速
│   ├── motor_test/main.py            ← 五步完整验证
│   ├── multi_motor/main.py           ← 多路并行与资源分配
│   └── calibrate/main.py             ← 双向前馈标定
├── docs/
│   ├── api.html                      ← API 手册（逐函数对照 Arduino 原库）
│   ├── tutorial.md                   ← 上手教程（Markdown）
│   ├── tutorial.html                 ← 上手教程（网页）
│   ├── tutorial.docx                 ← 上手教程（Word，含实物图）
│   └── images/                       ← 教程用图
├── README.md
└── SHA256SUMS.txt
```

前 5 个示例与官方 MicroPython 库一一对应，后 3 个是本移植新增。

---

## 3. 功能特性

| 功能 | 说明 |
|---|---|
| 双路 PWM 驱动 | 有符号占空比 `-1023..1023`，250 Hz / 10 位（与原库一致） |
| 刹车与关停 | `stop()` 制动（两脚拉高），`deinit()` 关停（两脚拉低，无驱动电流） |
| 正交编码计数 | PCNT 硬件解码，每脉冲 ±1，1 倍频，支持计数清零 |
| 转速测量 | 每 50 ms 采样一次，输出有符号 RPM |
| 速度闭环 | 设定目标 RPM 后自动调节占空比，带积分限幅与死区 |
| 相位关系可选 | A 相领先 / B 相领先，且支持运行期切换 |
| 多实例 | 每实例独立 PCNT 单元，共用 1 个硬件定时器 |
| 参数可配 | 引脚、PPR、减速比、PWM 频率与分辨率、速度 PID 均可设定 |
| 固件降级 | 无 `machine.Encoder` 的老固件自动回退到 `Pin.irq` 软件解码 |

---

## 4. 快速开始

### 4.1 部署

把 `lib/encoder_motor.py` 拷到板子根目录（或 `/lib`）。

**Thonny**：`视图 → 文件`，把文件拖到 `MicroPython 设备` 根目录。

**mpremote**：

```bash
mpremote fs cp lib/encoder_motor.py :encoder_motor.py
```

**示例程序**：把 `examples/<名字>/main.py` 拷到板子根目录并改名为 `main.py`，
上电自动运行；或在 REPL 里 `import main`。

### 4.2 最小示例

```python
import time
import encoder_motor as em

POS, NEG, ENC_A, ENC_B = 27, 13, 18, 19       # MAKER-ESP32-PRO 第 1 路
m = em.EncoderMotor(POS, NEG, ENC_A, ENC_B, 12, 90,
                    em.PHASE_RELATION_B_PHASE_LEADS)
m.init()

m.run_speed(50)                # 目标 50 RPM，定时器自动闭环
while True:
    time.sleep_ms(200)
    print("speed=%4d duty=%+5d pulses=%d" % (m.speed, m.pwm_duty, m.pulse_count))
```

不需要调用 `update()`。如需完全手动控制：`em.use_timer(False)`，此后在主循环里调 `m.update()`。

---

## 5. API 概要

### `class Motor`

| 接口 | 说明 |
|---|---|
| `Motor(positive_pin, negative_pin, pwm_frequency=250, pwm_resolution=10)` | 构造 |
| `init()` / `deinit()` | 初始化（制动）/ 关停（两脚拉低） |
| `run_pwm_duty(d)` | 有符号占空比，±1023 自动限幅 |
| `stop()` / `coast()` | 短路制动 / 自由滑行 |
| `pwm_duty` | 当前占空比（属性） |

### `class EncoderMotor`

| 接口 | 说明 |
|---|---|
| `EncoderMotor(pos, neg, a, b, ppr=12, reduction_ratio=90, phase_relation=0, encoder_id=None)` | 构造 |
| `init()` / `deinit()` | 分配 PCNT 单元并注册定时器 / 全部释放 |
| `run_pwm_duty(d)` | 开环，取消闭环目标 |
| `run_speed(rpm)` | 闭环目标转速 |
| `stop(brake=True)` | 停止（制动 / 滑行） |
| `pulse_count` / `reset_pulse_count()` | 累计脉冲 / 清零 |
| `speed` / `pwm_duty` / `target_rpm` | 当前转速 / 占空比 / 目标 |
| `set_speed_pid(p, i, d)` / `get_speed_pid()` | PID 参数 |
| `set_phase(phase)` | 运行期切换相位，返回 True/False |
| `set_feedforward(...)` / `set_duty_max(...)` | 死区前馈 / 输出上限（默认关闭） |
| `apply_calib(dict)` / `load_calib(ch)` | 标定结果套用 |
| `decoder` / `encoder_id` / `total_ppr` / `phase_relation` | 状态查询 |

同时也提供 Arduino 同名接口（`RunPwmDuty()` / `EncoderPulseCount()` / `SpeedRpm()` 等），
便于从 C++ 示例直接迁移。完整逐函数说明见 `docs/api.html`。

---

## 6. 三个关键实现决策

### 6.1 用 PCNT 而不是 GPIO 中断

原库用 C 层中断，在 A 相下降沿读 B 相判方向。Python 的 `Pin.irq` 是软中断，实测延迟在
**几百微秒到 1 毫秒**之间波动，而 100 RPM 时 90° 相位差只有 **134 µs**——采样点会落到
B 相跳变之后，导致方向判断错误。

| 方案 | 正反向对称性 | CPU 占用 |
|---|---|---|
| `Pin.irq` 软件解码 | 反向只有正向的 1/3，且随机 | 约 5% / 电机 |
| PCNT 硬件解码 | 差异 < 5% | 接近 0 |

### 6.2 共享硬件定时器，而不是要求用户调 `update()`

MicroPython 的 `_thread` 没有 `join`、没有条件变量，每个电机两个线程会吃掉几十 KB 栈。
改为**一个 50 ms 硬件定时器遍历所有实例**：

```python
def _shared_tick(timer):
    now = time.ticks_ms()
    for inst in tuple(_instances):
        try:
            inst._tick(now)
        except Exception:
            pass          # 单实例出错不影响其它路
```

### 6.3 制动用 GPIO 拉高，而不是 PWM 写满占空比

两者电气等价（两脚同时为高 = 绕组短接），但 LEDC 存在「从分数占空比跳到满占空比可能被
忽略」的固件差异——一旦发生，刹车会**静默失效**。改为释放 PWM、把引脚配成 GPIO 输出高，
行为确定，并且释放了 LEDC 通道。

实测制动衰减（停止后每 50 ms 剩余脉冲）：`[17, 0, 0, 0, 0, 0]`，50 ms 内停死。

---

## 7. 实测数据（MAKER-ESP32-PRO，12 V 供电）

| 项目 | 结果 |
|---|---|
| 每圈计数 | 1080（12 PPR × 90），积分法交叉验证比值 0.97~1.02 |
| 闭环 25 RPM | 实测 25.3，稳态纹波 ±1 |
| 闭环 60 RPM | 实测 59.3，稳态纹波 ±5 |
| 闭环 −60 RPM | 实测 −60.0，纹波 0 |
| 正反向对称性 | PCNT 解码后差异 < 5% |
| 计数范围 | +51238 / −48762 连续无回绕 |
| 多路并行 | 3 个编码电机 + 1 个直流电机同时运行，PCNT 单元 0/1/2 独立分配 |
| 路间干扰 | 单路满载使另一路占空比 +9（+3.4%） |

与官方 MicroPython 库（v2.0.0）同条件对比：转速精度均在 ±1.5 RPM，稳态占空比差异落在
重复测量的噪声范围内——**两者运行行为不可区分**。

---

## 8. 环境要求与已知限制

**必需**

- ESP32（经典款；ESP32-S3 需自行核对引脚）
- MicroPython **≥ 1.29**（需要 `machine.Encoder`；更低版本自动降级为软件解码）

**已知限制**

| 限制 | 说明 |
|---|---|
| 位置精度 | 1 倍频计数，1080 计数/圈；低速时 50 ms 窗口分辨率约 ±1 RPM |
| 浮点精度 | ESP32 端口为单精度，PID 积分长时间运行有微小漂移 |
| 定时器占用 | 多实例共用一个硬件 Timer（id 0~3 依次尝试），冲突时抛 `RuntimeError` |
| 电源依赖 | 两电机同时满载时母线电压约掉 3~11%，四电机需 ≥3 A 持续供电 |
| 软件回退路径 | 老固件的 `Pin.irq` 解码在高速下方向判据不可靠，仅作应急 |

**引脚提示**：MAKER-ESP32-PRO 的 E2/E3 使用 GPIO34/35/36/39，这几个脚只能输入且
**无内部上拉**，若编码器为开漏输出需外接 10 kΩ 上拉。

---

## 9. 验证记录

| 测试 | 示例 | 结论 |
|---|---|---|
| 五步功能验证 | `examples/motor_test` | 相位、开环、计数、测速、闭环全过 |
| 多路并行 | `examples/multi_motor` | 4 实例共存、资源分配与回收正常 |
| 双向前馈标定 | `examples/calibrate` | 生成 calib.json，换电压可重标 |
| 相位检测 | `examples/detect_phase_relation` | 自动判断 A/B 领先并可运行期纠偏 |
| 与官方库对比 | — | 同条件下转速精度一致，行为不可区分 |

---

## 10. 许可与致谢

- 上游：emakefun `em_esp32_encoder_motor` v1.2.0（MIT）
- 架构参考官方 MicroPython 库 v2.0.0，在其基础上增加了相位自检、多电压标定与异常隔离
