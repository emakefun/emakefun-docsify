(() => {

    'use strict';
    goog.require('Blockly.Lang.ZhHans');

    const { ZhHans } = Blockly.Lang;
	
	ZhHans.MIXLY_MAKER_ESP32_PRO_SERVO = "舵机引脚";

})();