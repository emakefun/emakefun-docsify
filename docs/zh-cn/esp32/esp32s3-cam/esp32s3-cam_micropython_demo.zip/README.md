# ESP32S3 CAM

## 示例

进入 MicroPython REPL 模式：

```bash
$ mpremote
>>> import exmple
SD卡初始化成功
摄像头抓拍系统准备就绪，按下 BOOT 按钮拍摄照片。
>>>
```

### 示例源代码：

```MicroPython
"""
exmple.py

ESP32S3 摄像头抓拍脚本，带SD卡存储功能
使用外部按钮中断触发照片抓拍
"""

import os
import time

import camera
from machine import Pin, SDCard

# 硬件初始化状态标志
sd_inited = False
camera_inited = False

# 初始化SD卡
try:
    # 配置SD卡的ESP32专用引脚映射
    # slot=0: 使用SDMMC外设
    # width=1: 1位数据模式
    # sck=39, cmd=38, data=40: GPIO引脚分配
    sd = SDCard(slot=0, width=1, sck=39, cmd=38, data=(40,))

    # 将SD卡挂载到文件系统的"/sd"挂载点
    os.mount(sd, "/sd")
    sd_inited = True
    print("SD卡初始化成功")
except Exception:
    # SD卡未找到或初始化失败
    print("SD卡未找到")


def camera_init():
    """
    初始化摄像头模块

    此函数尝试初始化摄像头，成功时设置全局camera_inited标志
    如果初始化失败，确保摄像头正确反初始化
    """
    global camera_inited

    try:
        # 使用默认参数初始化摄像头
        camera.init()
        camera_inited = True
        print("摄像头初始化成功")
    except Exception:
        # 确保失败时摄像头被反初始化
        camera.deinit()
        print("摄像头未找到或初始化失败")


def capture(button):
    """
    按钮按下的中断服务例程

    当按钮触发下降沿中断时调用此函数
    从摄像头抓拍照片并保存到存储设备
    """
    # 防抖延时，过滤按钮噪声
    time.sleep_ms(10)

    # 验证按钮是否仍被按下（低电平有效）
    if button.value() == 0:
        # 如果摄像头未初始化，则初始化
        if not camera_inited:
            camera_init()

        # 仅当摄像头正确初始化时才继续
        if camera_inited:
            try:
                # 这在低光条件下有助于改善拍摄效果
                camera.flashlamp(1)
                time.sleep_ms(50)

                # 从摄像头抓拍图像
                # 返回图像数据（字节）或失败时返回None
                # 闪光灯在抓拍期间保持开启以提供更好的照明
                buf = camera.capture()
            except Exception:
                print("摄像头抓拍失败 - 未接收到数据")
            finally:
                # 确保关闭闪光灯
                camera.flashlamp(0)

            # 使用当前时间戳生成文件名
            # time.ticks_ms()提供单调递增的时间戳
            saved_pic = f"/{time.ticks_ms()}.jpg"

            # 如果SD卡可用则使用SD卡路径，否则使用内部闪存
            if sd_inited:
                saved_pic = f"/sd{saved_pic}"

            # 将图像数据保存到文件
            with open(saved_pic, "wb") as f:
                f.write(buf)
                print(f"已保存 {saved_pic} ({len(buf)} 字节)")


# 在GPIO 0上配置按钮，使用内部上拉
# Pin.IN: 设置为输入引脚
button = Pin(0, Pin.IN)

# 配置下降沿中断（按钮按下）
# Pin.IRQ_FALLING: 信号从高电平到低电平时触发
# capture函数将作为中断服务例程被调用
button.irq(capture, Pin.IRQ_FALLING)

print("摄像头抓拍系统准备就绪，按下 BOOT 按钮拍摄照片。")
```

## `camera` - 摄像头驱动

### 基础函数

#### `camera.init(*)`

初始化摄像头，必须初始化后才能使用摄像头拍照图片。

- **关键词参数**
  - `format`, 图片数据格式

    | 格式               | 说明                |
    | ------------------ | ------------------- |
    | `camera.JPEG`      | JPEG 格式（默认值） |
    | `camera.YUV422`    | YUV422              |
    | `camera.GRAYSCALE` | GRAYSCALE           |
    | `camera.RGB565`    | RGB565              |

  - `framesize`, 分辨率（帧尺寸）

    | 分辨率（帧尺寸）       | 说明              |
    | ---------------------- | ----------------- |
    | `camera.FRAME_96X96`   | 96X96             |
    | `camera.FRAME_QQVGA`   | 160x120           |
    | `camera.FRAME_QCIF`    | 176x144           |
    | `camera.FRAME_HQVGA`   | 240x160           |
    | `camera.FRAME_240X240` | 240X240           |
    | `camera.FRAME_QVGA`    | 320x240           |
    | `camera.FRAME_CIF`     | 352x288           |
    | `camera.FRAME_HVGA`    | 480x320           |
    | `camera.FRAME_VGA`     | 640x480（默认值） |
    | `camera.FRAME_SVGA`    | 800x600           |
    | `camera.FRAME_XGA`     | 1024x768          |
    | `camera.FRAME_HD`      | 1280x720          |
    | `camera.FRAME_SXGA`    | 1280x1024         |
    | `camera.FRAME_UXGA`    | 1900x1200         |
    | `camera.FRAME_FHD`     | 1920x1080         |
    | `camera.FRAME_P_HD`    | 2560x1440         |
    | `camera.FRAME_P_3MP`   | 2048x1536         |
    | `camera.FRAME_QXGA`    | 2048x1536         |
    | `camera.FRAME_QHD`     | 2560x1440         |
    | `camera.FRAME_WQXGA`   | 2560x1600         |
    | `camera.FRAME_P_FHD`   | 2560x1600         |
    | `camera.FRAME_QSXGA`   | 2560x2048         |

  - `quality`，JPEG 质量，默认值：12，可选范围：0~63
  - `d0`，D0 引脚，默认值：11（ESP32S3 CAM 引脚值）
  - `d1`，D1 引脚，默认值：9（ESP32S3 CAM 引脚值）
  - `d2`，D2 引脚，默认值：8（ESP32S3 CAM 引脚值）
  - `d3`，D3 引脚，默认值：10（ESP32S3 CAM 引脚值）
  - `d4`，D4 引脚，默认值：12（ESP32S3 CAM 引脚值）
  - `d5`，D5 引脚，默认值：18（ESP32S3 CAM 引脚值）
  - `d6`，D6 引脚，默认值：17（ESP32S3 CAM 引脚值）
  - `d7`，D7 引脚，默认值：16（ESP32S3 CAM 引脚值）
  - `vsync`，VSYNC 引脚，默认值：6（ESP32S3 CAM 引脚值）
  - `href`，HREF 引脚，默认值：7（ESP32S3 CAM 引脚值）
  - `pclk`，PCLK 引脚，默认值：13（ESP32S3 CAM 引脚值）
  - `pwdn`，POWER 引脚，默认值：-1（不使用）
  - `reset`，RESET 引脚，默认值：-1（不使用）
  - `xclk`，XCLK 引脚，默认值：15（ESP32S3 CAM 引脚值）
  - `sda`，SDA 引脚，默认值：4（ESP32S3 CAM 引脚值）
  - `scl`，SCL 引脚，默认值：5（ESP32S3 CAM 引脚值）
  - `xclk_freq`，XCLK 信号频率，默认值：`camera.XCLK_10MHz`，可选值：`camera.XCLK_20MHz`
  - `fb_size`，帧缓存数量，默认值：1
  - `fb_location`，帧缓存区，默认值：`camera.DRAM`，可选值：`camera.PSRAM`

#### `camera.deinit()`

卸载摄像头，释放使用的硬件资源。

#### `camera.capture()`

拍摄 1 帧图片。

#### `camera.flashlamp(enable)`

使用板载闪光灯（ESP32S3 CAM 硬件特有函数）。

### 画面设置函数

#### `camera.framesize(framesize)`

重新设置分辨率（帧尺寸），参数具体值见前文。

#### `camera.quality(quality)`

重新设置 JPEG 质量，可选范围：0~63

#### `camera.flip(enable)`

设置画面上下颠倒。

#### `camera.mirror(enable)`

设置画面左右镜像。

#### `camera.contrast(contrast)`

设置画面对比度，默认值：0，可选范围：-2~2（高对比度）。

#### `camera.saturation(saturation)`

设置画面饱和度，默认值：0，可选范围：-2（灰度）~2。

#### `camera.brightness(brightness)`

设置画面亮度，默认值：0，可选范围：-2~2（高亮度）。

#### `camera.speffect(effect)`

设置画面特效。

| 特效                       | 说明           |
| -------------------------- | -------------- |
| `camera.EFFECT_NONE`       | 原图（默认值） |
| `camera.EFFECT_NEGATIVE`   |                |
| `camera.EFFECT_GRAYSCALE`  |                |
| `camera.EFFECT_SEPIA`      |                |
| `camera.EFFECT_RED`        |                |
| `camera.EFFECT_GREEN`      |                |
| `camera.EFFECT_BLUE`       |                |
| `camera.EFFECT_ANTIQUE`    |                |
| `camera.EFFECT_SKETCH`     |                |
| `camera.EFFECT_SOLARIZE`   |                |
| `camera.EFFECT_POSTERIZE`  |                |
| `camera.EFFECT_WHITEBOARD` |                |
| `camera.EFFECT_BLACKBOARD` |                |
| `camera.EFFECT_AQUA`       |                |

#### `camera.whitebalance(whitebalance)`

设置画面白平衡。

| 白平衡             | 说明           |
| ------------------ | -------------- |
| `camera.WB_NONE`   | 原图（默认值） |
| `camera.WB_SUNNY`  | 晴天           |
| `camera.WB_CLOUDY` | 阴天           |
| `camera.WB_OFFICE` | 办公室         |
| `camera.WB_HOME`   | 家中           |
