import time
from machine import Pin
p2 = Pin(2, Pin.OUT)
button_p0 = Pin(0, Pin.IN)    # create input pin on GPIO0
p2.value(0)

def p0_irq(button_p0):
    time.sleep_ms(10)
    if button_p0.value() == 0:
        print(p2.value())
        p2.value(not p2.value())  # revert p2 value

button_p0.irq(p0_irq, Pin.IRQ_FALLING)
