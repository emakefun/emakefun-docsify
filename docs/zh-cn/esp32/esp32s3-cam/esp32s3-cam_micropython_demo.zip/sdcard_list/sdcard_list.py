import machine, os
sd = machine.SDCard(slot=0, width=1, sck=39, cmd=38, data=(40,))
os.mount(sd, '/sd')
print(os.listdir('/sd'))
os.umount('/sd')
