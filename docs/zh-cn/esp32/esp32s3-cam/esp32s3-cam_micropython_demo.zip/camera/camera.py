import camera
 
 
# 初始化摄像头
try:
    camera.init(0, format=camera.JPEG)  # 使用try捕获初始化异常
except Exception as e:
    camera.deinit()  # 如果捕获到异常，则释放。
    camera.init(0, format=camera.JPEG)
 
# 拍摄一张图片
buf = camera.capture()  # 大小是640x480
 
# 保存图片到文件
with open("picture.png", "wb") as f:
    f.write(buf)  # buf中的数据就是图片的数据，所以直接写入到文件就行了
    print("拍照已完成，点击Thonny左侧【MicroPython设备】右侧的三，\n然后看到‘刷新’，点击刷新会看到 图片，\n然后右击图片名称，选择下载到电脑的路径即可...")
 
camera.deinit()  # 在使用摄像头后，调用camera.deinit释放