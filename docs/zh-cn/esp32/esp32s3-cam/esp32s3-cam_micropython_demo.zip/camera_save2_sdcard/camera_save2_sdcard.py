"""
ESP32S3 摄像头抓拍脚本，带SD卡存储功能
使用外部按钮中断触发照片抓拍
"""

import os
import time

import camera
from machine import Pin, SDCard

# 硬件初始化状态标志
sd_inited = False
camera_inited = False

# 初始化SD卡
try:
    # 配置SD卡的ESP32专用引脚映射
    # slot=0: 使用SDMMC外设
    # width=1: 1位数据模式
    # sck=39, cmd=38, data=40: GPIO引脚分配
    sd = SDCard(slot=0, width=1, sck=39, cmd=38, data=(40,))

    # 将SD卡挂载到文件系统的"/sd"挂载点
    os.mount(sd, "/sd")
    sd_inited = True
    print("SD卡初始化成功")
except Exception:
    # SD卡未找到或初始化失败
    print("SD卡未找到")


def camera_init():
    """
    初始化摄像头模块

    此函数尝试初始化摄像头，成功时设置全局camera_inited标志
    如果初始化失败，确保摄像头正确反初始化
    """
    global camera_inited

    try:
        # 使用默认参数初始化摄像头
        camera.init()
        camera_inited = True
        print("摄像头初始化成功")
    except Exception:
        # 确保失败时摄像头被反初始化
        camera.deinit()
        print("摄像头未找到或初始化失败")


def capture(button):
    """
    按钮按下的中断服务例程

    当按钮触发下降沿中断时调用此函数
    从摄像头抓拍照片并保存到存储设备
    """
    # 防抖延时，过滤按钮噪声
    time.sleep_ms(10)

    # 验证按钮是否仍被按下（低电平有效）
    if button.value() == 0:
        # 如果摄像头未初始化，则初始化
        if not camera_inited:
            camera_init()

        # 仅当摄像头正确初始化时才继续
        if camera_inited:
            try:
                # 这在低光条件下有助于改善拍摄效果
                camera.flashlamp(1)
                time.sleep_ms(50)

                # 从摄像头抓拍图像
                # 返回图像数据（字节）或失败时返回None
                # 闪光灯在抓拍期间保持开启以提供更好的照明
                buf = camera.capture()
            except Exception:
                print("摄像头抓拍失败 - 未接收到数据")
            finally:
                # 确保关闭闪光灯
                camera.flashlamp(0)

            # 使用当前时间戳生成文件名
            # time.ticks_ms()提供单调递增的时间戳
            saved_pic = f"/{time.ticks_ms()}.jpg"

            # 如果SD卡可用则使用SD卡路径，否则使用内部闪存
            if sd_inited:
                saved_pic = f"/sd{saved_pic}"

            # 将图像数据保存到文件
            with open(saved_pic, "wb") as f:
                f.write(buf)
                print(f"已保存 {saved_pic} ({len(buf)} 字节)")


# 在GPIO 0上配置按钮，使用内部上拉
# Pin.IN: 设置为输入引脚
button = Pin(0, Pin.IN)

# 配置下降沿中断（按钮按下）
# Pin.IRQ_FALLING: 信号从高电平到低电平时触发
# capture函数将作为中断服务例程被调用
button.irq(capture, Pin.IRQ_FALLING)

print("摄像头抓拍系统准备就绪，按下 BOOT 按钮拍摄照片。")
