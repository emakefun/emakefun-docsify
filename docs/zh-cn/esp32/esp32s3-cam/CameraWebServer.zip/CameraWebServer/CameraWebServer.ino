#include "esp_camera.h"
#include <WiFi.h>
#include <Preferences.h>

//
// WARNING!!! PSRAM IC required for UXGA resolution and high JPEG quality
//            Ensure ESP32 Wrover Module or other board with PSRAM is selected
//            Partial images will be transmitted if image exceeds buffer size
//
//            You must select partition scheme from the board menu that has at least 3MB APP space.
//            Face Recognition is DISABLED for ESP32 and ESP32-S2, because it takes up from 15
//            seconds to process single frame. Face Detection is ENABLED if PSRAM is enabled as well

// ===================
// Select camera model
// ===================
//#define CAMERA_MODEL_WROVER_KIT // Has PSRAM
//#define CAMERA_MODEL_ESP_EYE  // Has PSRAM
#define CAMERA_MODEL_ESP32S3_EYE // Has PSRAM
//#define CAMERA_MODEL_M5STACK_PSRAM // Has PSRAM
//#define CAMERA_MODEL_M5STACK_V2_PSRAM // M5Camera version B Has PSRAM
//#define CAMERA_MODEL_M5STACK_WIDE // Has PSRAM
//#define CAMERA_MODEL_M5STACK_ESP32CAM // No PSRAM
//#define CAMERA_MODEL_M5STACK_UNITCAM // No PSRAM
//#define CAMERA_MODEL_M5STACK_CAMS3_UNIT  // Has PSRAM
//#define CAMERA_MODEL_AI_THINKER // Has PSRAM
//#define CAMERA_MODEL_TTGO_T_JOURNAL // No PSRAM
//#define CAMERA_MODEL_XIAO_ESP32S3 // Has PSRAM
// ** Espressif Internal Boards **
//#define CAMERA_MODEL_ESP32_CAM_BOARD
//#define CAMERA_MODEL_ESP32S2_CAM_BOARD
//#define CAMERA_MODEL_ESP32S3_CAM_LCD
//#define CAMERA_MODEL_DFRobot_FireBeetle2_ESP32S3 // Has PSRAM
//#define CAMERA_MODEL_DFRobot_Romeo_ESP32S3 // Has PSRAM
#include "camera_pins.h"

// ===========================
// Enter your WiFi credentials
// ===========================

const char *ssid = "xxxxx";
const char *password = "xxxxxx";

void startCameraServer();
void setupLedFlash(int pin);

camera_config_t camera_config;

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("cam setup");
  Serial.setDebugOutput(true);
  Serial.println();

  camera_config.ledc_channel = LEDC_CHANNEL_0;
  camera_config.ledc_timer = LEDC_TIMER_0;
  camera_config.pin_d0 = Y2_GPIO_NUM;
  camera_config.pin_d1 = Y3_GPIO_NUM;
  camera_config.pin_d2 = Y4_GPIO_NUM;
  camera_config.pin_d3 = Y5_GPIO_NUM;
  camera_config.pin_d4 = Y6_GPIO_NUM;
  camera_config.pin_d5 = Y7_GPIO_NUM;
  camera_config.pin_d6 = Y8_GPIO_NUM;
  camera_config.pin_d7 = Y9_GPIO_NUM;
  camera_config.pin_xclk = XCLK_GPIO_NUM;
  camera_config.pin_pclk = PCLK_GPIO_NUM;
  camera_config.pin_vsync = VSYNC_GPIO_NUM;
  camera_config.pin_href = HREF_GPIO_NUM;
  camera_config.pin_sccb_sda = SIOD_GPIO_NUM;
  camera_config.pin_sccb_scl = SIOC_GPIO_NUM;
  camera_config.pin_pwdn = PWDN_GPIO_NUM;
  camera_config.pin_reset = RESET_GPIO_NUM;
  camera_config.xclk_freq_hz = 20000000;
  camera_config.frame_size = FRAMESIZE_UXGA;
  //camera_config.pixel_format = PIXFORMAT_JPEG;  // for streaming
  camera_config.pixel_format = PIXFORMAT_RGB565; // for face detection/recognition/GC2145
  camera_config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
  camera_config.fb_location = CAMERA_FB_IN_PSRAM;
  camera_config.jpeg_quality = 12;
  camera_config.fb_count = 1;

  // if PSRAM IC present, init with UXGA resolution and higher JPEG quality
  //                      for larger pre-allocated frame buffer.
  if (camera_config.pixel_format == PIXFORMAT_JPEG) {
    if (psramFound()) {
      camera_config.jpeg_quality = 10;
      camera_config.fb_count = 2;
      camera_config.grab_mode = CAMERA_GRAB_LATEST;
    } else {
      // Limit the frame size when PSRAM is not available
      camera_config.frame_size = FRAMESIZE_SVGA;
      camera_config.fb_location = CAMERA_FB_IN_DRAM;
    }
  } else {
    // Best option for face detection/recognition
    if (psramFound()) {
      camera_config.fb_count = 2;
      camera_config.grab_mode = CAMERA_GRAB_LATEST;
    }

    camera_config.frame_size = FRAMESIZE_QVGA;
#if CONFIG_IDF_TARGET_ESP32S3
    camera_config.fb_count = 2;
#endif
  }

  Preferences prefs;
  prefs.begin("cam", true);
  uint8_t boot_framesize = prefs.getUChar("framesize", FRAMESIZE_QVGA);
  uint8_t boot_vflip = prefs.getUChar("vflip", 1);
  uint8_t boot_hmirror = prefs.getUChar("hmirror", 0);
  uint8_t boot_xclk = prefs.getUChar("xclk", 24);
  prefs.end();
  if (boot_xclk < 6 || boot_xclk > 27) {
    boot_xclk = 24;
  }
  camera_config.frame_size = (framesize_t)boot_framesize;

#if defined(CAMERA_MODEL_ESP_EYE)
  pinMode(13, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);
#endif

  // camera init
    Serial.println("esp_camera_init");
  esp_err_t err = esp_camera_init(&camera_config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }
    Serial.println("esp_camera_init ok");
  sensor_t *s = esp_camera_sensor_get();
  if (s->id.PID == GC2145_PID)
  {
    if (boot_framesize != FRAMESIZE_QCIF && boot_framesize != FRAMESIZE_QVGA &&
        boot_framesize != FRAMESIZE_VGA && boot_framesize != FRAMESIZE_SVGA &&
        boot_framesize != FRAMESIZE_HD) {
      boot_framesize = FRAMESIZE_QVGA;
    }
    camera_config.frame_size = (framesize_t)boot_framesize;
    Serial.printf("Detected GC2145, re-initializing with %dMHz...\n", boot_xclk);
    esp_camera_deinit();
    camera_config.xclk_freq_hz = boot_xclk * 1000000;
    Serial.println("GC2145 camera init");
    if (esp_camera_init(&camera_config) != ESP_OK)
    {
      Serial.println("Camera init fail!");
      return;
    }
    s = esp_camera_sensor_get();
  }
  else
  {
    camera_config.pixel_format = PIXFORMAT_JPEG;
    camera_config.xclk_freq_hz = 20000000;
    camera_config.jpeg_quality = 10;
    camera_config.fb_count = 2;
    camera_config.grab_mode = CAMERA_GRAB_LATEST;
    camera_config.frame_size = FRAMESIZE_UXGA;
    Serial.println("Detected JPEG sensor, re-initializing with JPEG...");
    esp_camera_deinit();
    if (esp_camera_init(&camera_config) != ESP_OK)
    {
      Serial.println("Camera init fail!");
      return;
    }
    s = esp_camera_sensor_get();
    if (s->id.PID == OV3660_PID) {
      s->set_vflip(s, 1);        // flip it back
      s->set_brightness(s, 1);   // up the brightness just a bit
      s->set_saturation(s, -2);  // lower the saturation
    }
  }
  // drop down frame size for higher initial frame rate
  if (camera_config.pixel_format == PIXFORMAT_JPEG) {
    s->set_framesize(s, FRAMESIZE_QVGA);
  }

#if defined(CAMERA_MODEL_M5STACK_WIDE) || defined(CAMERA_MODEL_M5STACK_ESP32CAM)
  s->set_vflip(s, 1);
  s->set_hmirror(s, 1);
#endif

#if defined(CAMERA_MODEL_ESP32S3_EYE)
  s->set_vflip(s, boot_vflip);
  s->status.vflip = boot_vflip;
#endif

// Setup LED FLash if LED pin is defined in camera_pins.h
#if defined(LED_GPIO_NUM)
  setupLedFlash(LED_GPIO_NUM);
#endif
  Serial.println("wifi connect start");
  WiFi.begin(ssid, password);
  WiFi.setSleep(false);

  Serial.print("WiFi connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected");

  startCameraServer();

  Serial.print("Camera Ready! Use 'http://");
  Serial.print(WiFi.localIP());
  Serial.println("' to connect");
}

void loop() {
  // Do nothing. Everything is done in another task by the web server
  delay(10000);
}
