#include <AccelStepper.h>

namespace {
// 步进电机 1 的引脚定义：A相（正/负）、B相（正/负）
constexpr gpio_num_t kStepper1APosPin = GPIO_NUM_27;  // A+ 引脚
constexpr gpio_num_t kStepper1ANegPin = GPIO_NUM_13;  // A- 引脚
constexpr gpio_num_t kStepper1BPosPin = GPIO_NUM_4;   // B+ 引脚
constexpr gpio_num_t kStepper1BNegPin = GPIO_NUM_2;   // B- 引脚

// 步进电机 2 的引脚定义
constexpr gpio_num_t kStepper2APosPin = GPIO_NUM_17;  // A+ 引脚
constexpr gpio_num_t kStepper2ANegPin = GPIO_NUM_12;  // A- 引脚
constexpr gpio_num_t kStepper2BPosPin = GPIO_NUM_14;  // B+ 引脚
constexpr gpio_num_t kStepper2BNegPin = GPIO_NUM_15;  // B- 引脚

// 创建 AccelStepper 对象，构造函数参数顺序： 步进模式，A+, A-, B+, B-
AccelStepper g_stepper1(AccelStepper::HALF4WIRE, kStepper1APosPin, kStepper1ANegPin, kStepper1BPosPin, kStepper1BNegPin);
AccelStepper g_stepper2(AccelStepper::HALF4WIRE, kStepper2APosPin, kStepper2ANegPin, kStepper2BPosPin, kStepper2BNegPin);

constexpr float kMaxSpeed = 1600;
constexpr uint32_t kIntervalTime = 3000;

uint32_t g_trigger_time = 0;
int32_t g_target_speed = 1600;
}  // namespace

void setup() {
  Serial.begin(115200);

  g_stepper1.setMaxSpeed(kMaxSpeed);
  g_stepper2.setMaxSpeed(kMaxSpeed);
}

void loop() {
  if (g_trigger_time == 0 || millis() - g_trigger_time > kIntervalTime) {
    g_trigger_time = millis();
    g_stepper1.setSpeed(g_target_speed);
    g_stepper2.setSpeed(g_target_speed);
    g_target_speed = -g_target_speed;
  }

  g_stepper1.runSpeed();
  g_stepper2.runSpeed();
}