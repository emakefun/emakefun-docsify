namespace {
constexpr uint8_t kTouchPin = 3;  // 定义碰触开关引脚
constexpr uint8_t kLedOut = 4;    // 定义LED引脚

int8_t g_collision_value = 0;  // 存储碰撞检测值
}  // namespace

void setup() {
  pinMode(kTouchPin, INPUT);
  pinMode(kLedOut, OUTPUT);
}

void loop() {
  g_collision_value = digitalRead(kTouchPin);
  if (g_collision_value == LOW) {
    digitalWrite(kLedOut, HIGH);
  } else {
    digitalWrite(kLedOut, LOW);
  }
}