#include "JoystickHandle.h"

namespace {
JoystickHandle g_joystickHandle(JOYSTICK_I2C_ADDR);
}  // namespace

void setup() {
    Serial.begin(115200);  // 设置波特率
}

void loop() {
    if (g_joystickHandle.Get_Button_Status(BUTTON_A) == PRESS_DOWN) {  // 判断按键A是否按下
        Serial.println("Button_A Pressed.");
    }
    if (g_joystickHandle.Get_Button_Status(BUTTON_B) == PRESS_DOWN) {  // 判断按键B是否按下
        Serial.println("Button_B Pressed.");
    }
    if (g_joystickHandle.Get_Button_Status(BUTTON_C) == PRESS_DOWN) {  // 判断按键C是否按下
        Serial.println("Button_C Pressed.");
    }
    if (g_joystickHandle.Get_Button_Status(BUTTON_D) == PRESS_DOWN) {  // 判断按键D是否按下
        Serial.println("Button_D Pressed.");
    }
    if (g_joystickHandle.Get_Button_Status(BUTTON_OK) == PRESS_DOWN) {  // 判断摇杆按键是否按下
        Serial.println("Button OK Pressed.");
    }
    Serial.print("Value_X:");
    Serial.println(g_joystickHandle.AnalogRead_X());  // 读取摇杆X轴的模拟值打印出来
    Serial.print("Value_Y:");
    Serial.println(g_joystickHandle.AnalogRead_Y());  // 读取摇杆Y轴的模拟值打印出来
    delay(50);
}