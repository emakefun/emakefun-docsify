#include "JoystickHandle.h"

JoystickHandle myJoystickHandle(JOYSTICK_I2C_ADDR);

void setup(){
  Serial.begin(9600);
}

void loop(){
  if (myJoystickHandle.Get_Button_Status(BUTOON_A)==PRESS_DOWN) {  // 判断按键A是否按下
    Serial.println("Button_A Pressed");
  }
  if (myJoystickHandle.Get_Button_Status(BUTOON_B)==PRESS_DOWN) {  // 判断按键B是否按下
    Serial.println("Button_B Pressed");
  }
  if (myJoystickHandle.Get_Button_Status(BUTOON_C)==PRESS_DOWN) {  // 判断按键C是否按下
    Serial.println("Button_C Pressed");
  }
  if (myJoystickHandle.Get_Button_Status(BUTOON_D)==PRESS_DOWN) {  // 判断按键D是否按下
    Serial.println("Button_D Pressed");
  }
  if (myJoystickHandle.Get_Button_Status(BUTOON_OK)==PRESS_DOWN) {  // 判断摇杆按键是否按下
    Serial.println("Button OK Pressed");
  }
  Serial.print("Value_X:");
  Serial.println(myJoystickHandle.AnalogRead_X()); // 读取摇杆X轴的模拟值打印出来
  Serial.print("Value_Y:");
  Serial.println(myJoystickHandle.AnalogRead_Y()); // 读取摇杆Y轴的模拟值打印出来
 // Serial.println(myJoystickHandle.Get_Button_Status(BUTOON_A));
  delay(50);
}
