from microbit import *

sta = 0
sta_key = 0
scanResult = 0
EC11_B = 0
EC11_A = 0
key = 0

pin1.set_pull(pin1.PULL_UP)
pin2.set_pull(pin2.PULL_UP)
pin8.set_pull(pin8.PULL_UP)

while True:
    key = pin8.read_digital()
    EC11_A = pin1.read_digital()
    EC11_B = pin2.read_digital()
    scanResult = 0

    if sta_key == 0 and key == 1:
        sta_key = 1
    elif sta_key == 1:
        if key == 0:
            sta_key = 2
    elif sta_key == 2:
        if key == 1:
            sta_key = 0
            scanResult = 3

    if EC11_A == 0 and sta == 0:
        sta = 1
    elif sta == 1:
        if EC11_A == 1:
            if EC11_B == 1:
                if key == 0:
                    scanResult = 2
                    sta_key = 0
                else:
                    scanResult += 1
            elif EC11_B == 0:
                if key == 0:
                    scanResult = -2
                    sta_key = 0
                else:
                    scanResult += -1
                sta = 0

    if scanResult != 0:
        display.scroll(str(scanResult))
