namespace {
constexpr uint8_t kLedOut = 3;
constexpr uint8_t kKeypadPin = A3;

int8_t g_button_value = 0;
}  // namespace

void setup() {
  pinMode(kLedOut, OUTPUT);
  pinMode(kKeypadPin, INPUT);
}

void loop() {
  g_button_value = digitalRead(kKeypadPin);
  if (g_button_value == LOW) {
    digitalWrite(kLedOut, HIGH);
  } else {
    digitalWrite(kLedOut, LOW);
  }
}