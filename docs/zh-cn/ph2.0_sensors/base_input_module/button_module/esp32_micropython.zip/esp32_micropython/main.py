from machine import Pin

button = Pin(5, Pin.IN)
led = Pin(2, Pin.OUT)
while True:
    if button.value() == 0:
        led.value(1)   #按下打印相应信息
    else:
        led.value(0)
