import machine
import time
from micropython import const


class AdcKeyboard:
    _KEY_A_THRESHOLD: tuple = (round(2866.5), round(3685.5))
    _KEY_B_THRESHOLD: tuple = (round(2047.5), round(2866.5))
    _KEY_C_THRESHOLD: tuple = (round(1228.5), round(2047.5))
    _KEY_D_THRESHOLD: tuple = (round(409.5), round(819))
    _KEY_E_THRESHOLD: tuple = (0, round(409.5))

    KEY_A: int = const(0)
    KEY_B: int = const(1)
    KEY_C: int = const(2)
    KEY_D: int = const(3)
    KEY_E: int = const(4)

    def __init__(self, pin) -> None:
        self._adc = machine.ADC(pin, atten=machine.ADC.ATTN_11DB)
        self._current_value = None
        self._last_value = None
        self._debounce_time = 0
        self._last_key_state = None
        self._key_state = None

    def _read(self):
        adc_value = self._adc.read()
        if adc_value >= AdcKeyboard._KEY_A_THRESHOLD[
                0] and adc_value < AdcKeyboard._KEY_A_THRESHOLD[1]:
            return AdcKeyboard.KEY_A
        elif adc_value >= AdcKeyboard._KEY_B_THRESHOLD[
                0] and adc_value < AdcKeyboard._KEY_B_THRESHOLD[1]:
            return AdcKeyboard.KEY_B
        elif adc_value >= AdcKeyboard._KEY_C_THRESHOLD[
                0] and adc_value < AdcKeyboard._KEY_C_THRESHOLD[1]:
            return AdcKeyboard.KEY_C
        elif adc_value >= AdcKeyboard._KEY_D_THRESHOLD[
                0] and adc_value < AdcKeyboard._KEY_D_THRESHOLD[1]:
            return AdcKeyboard.KEY_D
        elif adc_value >= AdcKeyboard._KEY_E_THRESHOLD[
                0] and adc_value < AdcKeyboard._KEY_E_THRESHOLD[1]:
            return AdcKeyboard.KEY_E
        else:
            return None

    def _debounced_value(self):
        value = self._read()

        if self._current_value != value:
            self._current_value = value
            self._debounce_time = time.ticks_ms()
        elif self._last_value != value and time.ticks_ms(
        ) - self._debounce_time > 50:
            self._last_value = value

        return self._last_value

    def tick(self):
        self._last_key_state = self._key_state
        self._key_state = self._debounced_value()

    def pressed(self, key):
        return self._last_key_state != key and self._key_state == key

    def pressing(self, key):
        return self._key_state == key and self._last_key_state == self._key_state

    def released(self, key):
        return self._key_state != key and self._last_key_state == key
