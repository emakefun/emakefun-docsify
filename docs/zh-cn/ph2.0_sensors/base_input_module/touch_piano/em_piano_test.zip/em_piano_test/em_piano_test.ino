#include "em_piano.h"

namespace {
constexpr uint8_t kClkPin = 7;   // 时钟引脚 (Arduino UNO)
constexpr uint8_t kDioPin = A0;  // 数据引脚 (Arduino UNO)
// 若使用 ESP32，可改为 kClkPin = 22, kDioPin = 21

Piano g_piano;  // 钢琴模块全局对象
}  // namespace

void setup() {
  Serial.begin(115200);  // 设置波特率

  g_piano.initPiano(kClkPin, kDioPin);  // 初始化触摸钢琴模块
}

void loop() {
  if (g_piano.PressBsButton(EM_PIANO_KEYCODE_1)) {
    Serial.println("Touch key 1");
  } else if (g_piano.PressBsButton(EM_PIANO_KEYCODE_2)) {
    Serial.println("Touch key 2");
  } else if (g_piano.PressBsButton(EM_PIANO_KEYCODE_3)) {
    Serial.println("Touch key 3");
  } else if (g_piano.PressBsButton(EM_PIANO_KEYCODE_4)) {
    Serial.println("Touch key 4");
  } else if (g_piano.PressBsButton(EM_PIANO_KEYCODE_5)) {
    Serial.println("Touch key 5");
  } else if (g_piano.PressBsButton(EM_PIANO_KEYCODE_6)) {
    Serial.println("Touch key 6");
  } else if (g_piano.PressBsButton(EM_PIANO_KEYCODE_7)) {
    Serial.println("Touch key 7");
  } else if (g_piano.PressBsButton(EM_PIANO_KEYCODE_8)) {
    Serial.println("Touch key 8");
  }

  delay(100);
}