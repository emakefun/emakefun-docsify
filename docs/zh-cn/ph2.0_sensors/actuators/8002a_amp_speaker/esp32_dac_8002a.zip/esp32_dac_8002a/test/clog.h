#pragma once

#ifndef __CLOG_H__
#define __CLOG_H__

#include "clog_esp32.h"

#endif