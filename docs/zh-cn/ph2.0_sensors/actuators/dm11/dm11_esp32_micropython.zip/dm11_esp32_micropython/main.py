from dm11 import DM11
import time
from machine import Pin, I2C


print("set up")
i2c = I2C(0, sda=Pin(21), scl=Pin(22))
dm11 = DM11(i2c)

print("setup successful")

while True:
    dm11.set_pwm_duty(0, 0)
    dm11.set_pwm_duty(1, 4095)
    dm11.set_pwm_duty(2, 0)
    dm11.set_pwm_duty(3, 4095)

    time.sleep(1)

    dm11.set_pwm_duty(0, 4095)
    dm11.set_pwm_duty(1, 0)
    dm11.set_pwm_duty(2, 4095)
    dm11.set_pwm_duty(3, 0)

    time.sleep(1)
