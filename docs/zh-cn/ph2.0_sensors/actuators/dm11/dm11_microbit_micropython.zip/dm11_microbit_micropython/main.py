from dm11 import DM11
import time
from microbit import *


print("set up")
dm11 = DM11()

print("setup successful")

while True:
    dm11.set_pwm_duty(0, 0)
    dm11.set_pwm_duty(1, 4095)
    dm11.set_pwm_duty(2, 0)
    dm11.set_pwm_duty(3, 4095)

    time.sleep_ms(1000)

    dm11.set_pwm_duty(0, 4095)
    dm11.set_pwm_duty(1, 0)
    dm11.set_pwm_duty(2, 4095)
    dm11.set_pwm_duty(3, 0)

    time.sleep_ms(1000)
