var examples =
[
    [ "detect_phase_relation.ino", "detect_phase_relation_8ino-example.html", null ],
    [ "drive_dc_motor.ino", "drive_dc_motor_8ino-example.html", null ],
    [ "forward_stop_backward.ino", "forward_stop_backward_8ino-example.html", null ],
    [ "run_pwm.ino", "run_pwm_8ino-example.html", null ],
    [ "run_rpm_with_analog_input.ino", "run_rpm_with_analog_input_8ino-example.html", null ],
    [ "run_speed.ino", "run_speed_8ino-example.html", null ]
];