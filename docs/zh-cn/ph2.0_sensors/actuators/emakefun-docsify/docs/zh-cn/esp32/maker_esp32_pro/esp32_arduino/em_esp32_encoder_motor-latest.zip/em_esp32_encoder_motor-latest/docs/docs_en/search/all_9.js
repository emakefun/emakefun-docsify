var searchData=
[
  ['setspeedpid_0',['SetSpeedPid',['../classem_1_1_encoder_motor.html#a8e833aafb82e8a610dbb60700e3a1a8e',1,'em::EncoderMotor']]],
  ['speedrpm_1',['SpeedRpm',['../classem_1_1_encoder_motor.html#ae03160a42fcd772dc2455a7b530e488e',1,'em::EncoderMotor']]],
  ['stop_2',['Stop',['../classem_1_1_encoder_motor.html#a265c579b3e27e4cd11e88b47fec5f3b5',1,'em::EncoderMotor::Stop()'],['../classem_1_1_motor.html#ac43aeb3999c588ba10be5230c6019453',1,'em::Motor::Stop()']]]
];
