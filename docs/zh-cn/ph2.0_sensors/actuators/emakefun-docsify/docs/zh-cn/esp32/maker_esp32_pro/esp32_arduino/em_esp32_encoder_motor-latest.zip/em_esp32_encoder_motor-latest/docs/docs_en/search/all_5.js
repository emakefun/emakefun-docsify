var searchData=
[
  ['kaphaseleads_0',['kAPhaseLeads',['../classem_1_1_encoder_motor.html#a69db8b9fc364d4d8f2509473d759ed0fabaf116cc352898fa6df6ef8ea8db13dc',1,'em::EncoderMotor']]],
  ['kbphaseleads_1',['kBPhaseLeads',['../classem_1_1_encoder_motor.html#a69db8b9fc364d4d8f2509473d759ed0fa7086fd10e3da29b4359295cf6e3536f6',1,'em::EncoderMotor']]],
  ['kmaxpwmduty_2',['kMaxPwmDuty',['../classem_1_1_motor.html#a6a329178a1c6fb0b5c71c43fc951247b',1,'em::Motor']]],
  ['kpwmfrequency_3',['kPwmFrequency',['../classem_1_1_motor.html#ae8896242118d010267612ab03c1847a4',1,'em::Motor']]],
  ['kpwmresolution_4',['kPwmResolution',['../classem_1_1_motor.html#a182d4dcd83fa90f2e7a662040b0a03b5',1,'em::Motor']]],
  ['kversionmajor_5',['kVersionMajor',['../encoder__motor__lib_8h.html#aa404b9ca9a981668738dfc3680098ba1',1,'em::esp_encoder_motor_lib']]],
  ['kversionminor_6',['kVersionMinor',['../encoder__motor__lib_8h.html#aaafe39b3e927393ae04852d63ab1af76',1,'em::esp_encoder_motor_lib']]],
  ['kversionpatch_7',['kVersionPatch',['../encoder__motor__lib_8h.html#a7ba56018a7721893d78ccf5c414d4b3c',1,'em::esp_encoder_motor_lib']]]
];
