var searchData=
[
  ['kmaxpwmduty_0',['kMaxPwmDuty',['../classem_1_1_motor.html#a6a329178a1c6fb0b5c71c43fc951247b',1,'em::Motor']]],
  ['kpwmfrequency_1',['kPwmFrequency',['../classem_1_1_motor.html#ae8896242118d010267612ab03c1847a4',1,'em::Motor']]],
  ['kpwmresolution_2',['kPwmResolution',['../classem_1_1_motor.html#a182d4dcd83fa90f2e7a662040b0a03b5',1,'em::Motor']]],
  ['kversionmajor_3',['kVersionMajor',['../encoder__motor__lib_8h.html#aa404b9ca9a981668738dfc3680098ba1',1,'em::esp_encoder_motor_lib']]],
  ['kversionminor_4',['kVersionMinor',['../encoder__motor__lib_8h.html#aaafe39b3e927393ae04852d63ab1af76',1,'em::esp_encoder_motor_lib']]],
  ['kversionpatch_5',['kVersionPatch',['../encoder__motor__lib_8h.html#a7ba56018a7721893d78ccf5c414d4b3c',1,'em::esp_encoder_motor_lib']]]
];
