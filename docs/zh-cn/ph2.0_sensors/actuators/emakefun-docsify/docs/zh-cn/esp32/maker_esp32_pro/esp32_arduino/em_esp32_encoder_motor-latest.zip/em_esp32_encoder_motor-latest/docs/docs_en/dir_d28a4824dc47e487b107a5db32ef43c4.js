var dir_d28a4824dc47e487b107a5db32ef43c4 =
[
    [ "detect_phase_relation", "dir_48f34669938960b084b7a76e0f046786.html", "dir_48f34669938960b084b7a76e0f046786" ],
    [ "drive_dc_motor", "dir_9fece40de232b54cf09174cb2a0a4e19.html", "dir_9fece40de232b54cf09174cb2a0a4e19" ],
    [ "forward_stop_backward", "dir_0bb2362611ff25b75da164d8dc3899fb.html", "dir_0bb2362611ff25b75da164d8dc3899fb" ],
    [ "run_pwm", "dir_59fb54ade1c78ad5685391a82a86486f.html", "dir_59fb54ade1c78ad5685391a82a86486f" ],
    [ "run_rpm_with_analog_input", "dir_a62fe87c167dbf6f4b69749163ef54f5.html", "dir_a62fe87c167dbf6f4b69749163ef54f5" ],
    [ "run_speed", "dir_0c63d8d4f3de2606d57369b5a4e4b1b3.html", "dir_0c63d8d4f3de2606d57369b5a4e4b1b3" ]
];