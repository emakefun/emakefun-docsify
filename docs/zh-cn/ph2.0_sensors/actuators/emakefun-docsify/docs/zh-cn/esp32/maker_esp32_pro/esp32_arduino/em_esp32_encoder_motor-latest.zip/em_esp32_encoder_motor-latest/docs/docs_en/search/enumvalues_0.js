var searchData=
[
  ['kaphaseleads_0',['kAPhaseLeads',['../classem_1_1_encoder_motor.html#a69db8b9fc364d4d8f2509473d759ed0fabaf116cc352898fa6df6ef8ea8db13dc',1,'em::EncoderMotor']]],
  ['kbphaseleads_1',['kBPhaseLeads',['../classem_1_1_encoder_motor.html#a69db8b9fc364d4d8f2509473d759ed0fa7086fd10e3da29b4359295cf6e3536f6',1,'em::EncoderMotor']]]
];
