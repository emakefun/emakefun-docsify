var classem_1_1_encoder_motor =
[
    [ "PhaseRelation", "classem_1_1_encoder_motor.html#a69db8b9fc364d4d8f2509473d759ed0f", [
      [ "kAPhaseLeads", "classem_1_1_encoder_motor.html#a69db8b9fc364d4d8f2509473d759ed0fabaf116cc352898fa6df6ef8ea8db13dc", null ],
      [ "kBPhaseLeads", "classem_1_1_encoder_motor.html#a69db8b9fc364d4d8f2509473d759ed0fa7086fd10e3da29b4359295cf6e3536f6", null ]
    ] ],
    [ "EncoderMotor", "classem_1_1_encoder_motor.html#aab433c4bd09df5293857adbf396f9087", null ],
    [ "EncoderPulseCount", "classem_1_1_encoder_motor.html#a8a9fedb2482c88418b244c4794d427dd", null ],
    [ "GetSpeedPid", "classem_1_1_encoder_motor.html#a4bf31cd9c310102dec61659b5a969184", null ],
    [ "Init", "classem_1_1_encoder_motor.html#a12e18423baa47264af3960c120dcea6f", null ],
    [ "PwmDuty", "classem_1_1_encoder_motor.html#a2b3c2fff560cf81991dc98c58023d3e5", null ],
    [ "RunPwmDuty", "classem_1_1_encoder_motor.html#a78c6dd66d03d8c2d9f98041f400c396a", null ],
    [ "RunSpeed", "classem_1_1_encoder_motor.html#a3fdd02d1351ea0061a20e1dbe945b35c", null ],
    [ "SetSpeedPid", "classem_1_1_encoder_motor.html#a8e833aafb82e8a610dbb60700e3a1a8e", null ],
    [ "SpeedRpm", "classem_1_1_encoder_motor.html#ae03160a42fcd772dc2455a7b530e488e", null ],
    [ "Stop", "classem_1_1_encoder_motor.html#a265c579b3e27e4cd11e88b47fec5f3b5", null ],
    [ "TargetRpm", "classem_1_1_encoder_motor.html#a8e41301b0622532cc66c59cfeb56684a", null ]
];