var encoder__motor__lib_8h =
[
    [ "Version", "encoder__motor__lib_8h.html#a09d0e6caa15faae786c03addbc6d3c65", null ],
    [ "kVersionMajor", "encoder__motor__lib_8h.html#aa404b9ca9a981668738dfc3680098ba1", null ],
    [ "kVersionMinor", "encoder__motor__lib_8h.html#aaafe39b3e927393ae04852d63ab1af76", null ],
    [ "kVersionPatch", "encoder__motor__lib_8h.html#a7ba56018a7721893d78ccf5c414d4b3c", null ]
];