var searchData=
[
  ['detect_5fphase_5frelation_2eino_0',['detect_phase_relation.ino',['../detect__phase__relation_8ino.html',1,'']]],
  ['drive_5fdc_5fmotor_2eino_1',['drive_dc_motor.ino',['../drive__dc__motor_8ino.html',1,'']]]
];
