from ec11 import Rotary
import utime as time

rotary = Rotary(26, 27, 25)  # dt, clk, sw -> pinB, pinA, pinD
val = 0


def rotary_changed(change):
    global val
    if change == Rotary.ROT_CW:
        val = val + 1
        print(val)
    elif change == Rotary.ROT_CCW:
        val = val - 1
        print(val)
    elif change == Rotary.SW_PRESS:
        print("PRESS")
    elif change == Rotary.SW_RELEASE:
        print("RELEASE")


rotary.add_handler(rotary_changed)

while True:
    time.sleep(999)
