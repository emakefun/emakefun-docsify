var searchData=
[
  ['read_5ffrom_5fdevice_2eino_0',['read_from_device.ino',['../read__from__device_8ino.html',1,'']]],
  ['read_5fprotocol_1',['read_protocol',['../classem_1_1_asr_speech_recognition.html#a1b5f57da91d7829385a91b2ae83e9aab',1,'em::AsrSpeechRecognition']]]
];
