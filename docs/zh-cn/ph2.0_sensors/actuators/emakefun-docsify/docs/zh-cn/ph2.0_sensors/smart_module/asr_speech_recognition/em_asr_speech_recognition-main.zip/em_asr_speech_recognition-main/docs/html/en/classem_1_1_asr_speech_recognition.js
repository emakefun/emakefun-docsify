var classem_1_1_asr_speech_recognition =
[
    [ "AsrSpeechRecognition", "classem_1_1_asr_speech_recognition.html#a491ac6ecaa3a72720640546bee082347", null ],
    [ "read_protocol", "classem_1_1_asr_speech_recognition.html#a1b5f57da91d7829385a91b2ae83e9aab", null ]
];