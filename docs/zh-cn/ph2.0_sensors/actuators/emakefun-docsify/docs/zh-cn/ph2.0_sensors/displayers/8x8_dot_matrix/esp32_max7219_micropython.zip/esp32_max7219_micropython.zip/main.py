import machine
from matrix_led_8x8 import MatrixLed8x8

spi=machine.SPI(1, sck=27, mosi=25)

matrix_led_8x8 = MatrixLed8x8(spi=spi, cs=26)
matrix_led_8x8.show_number(1234)