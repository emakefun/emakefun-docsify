var searchData=
[
  ['asr_5fserial_5fbaud_5frate_0',['ASR_SERIAL_BAUD_RATE',['../asr__speech__recognition_8h.html#af88ea9f9e00bcb7d00ae5e3b8c3e32e6',1,'asr_speech_recognition.h']]]
];
