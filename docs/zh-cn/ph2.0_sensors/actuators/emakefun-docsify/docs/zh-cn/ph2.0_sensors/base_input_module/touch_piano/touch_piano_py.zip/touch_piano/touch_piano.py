import machine
import time
from machine import Pin
from debouncer import Debouncer
class TouchPiano:
    def __init__(self, pin_clk,pin_dio):
        self.pin_clk = pin_clk
        self.pin_dio = pin_dio
        self.current_key_value = 0
        self.last_read_code_time = 0
        self.last_code = 0
        self.p0 = Pin(self.pin_clk, Pin.OUT)
        self.p1 = Pin(self.pin_dio, Pin.IN)
        self.debouncer = Debouncer()
        self.debouncer.start(10,0XFFFF)

    def tick(self):
        self.last_key_value = self.current_key_value
        self.current_key_value = self.debouncer.debounce(self.read_code())

    def read_code(self):    
        self.now = time.ticks_ms()
        if self.now - self.last_read_code_time < 5 :
            return self.last_code
        self.last_code = 0
        self.p1 = Pin(self.pin_dio,Pin.OUT)
        self.p1.on()
        time.sleep_us(100)
        self.p1.off()
        time.sleep_us(10)
        self.p1 = Pin(self.pin_dio,Pin.IN)
        for i in range(0,16):
            self.p0.on()
            time.sleep_us(100)
            self.p0.off()
            time.sleep_us(1)
            self.last_code |= (self.p1.value() << i)
            
        self.last_read_code_time = self.now 
        return self.last_code
        
    def pressed(self,key):  
        return (self.last_key_value != key) and (self.current_key_value == key)
        
    def released(self,key):
        return (self.last_key_value == key) and (self.current_key_value != key)

    def pressing(self,key):
        return (self.last_key_value == key) and (self.current_key_value == key)