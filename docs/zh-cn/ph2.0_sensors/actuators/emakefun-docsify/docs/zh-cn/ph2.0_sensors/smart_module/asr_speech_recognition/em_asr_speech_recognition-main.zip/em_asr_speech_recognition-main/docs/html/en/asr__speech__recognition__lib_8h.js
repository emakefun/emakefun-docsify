var asr__speech__recognition__lib_8h =
[
    [ "em::asr_speech_recognition_lib::Version", "asr__speech__recognition__lib_8h.html#a4909c5c2782e02e6896ad539f40a1e6f", null ],
    [ "em::asr_speech_recognition_lib::kVersionMajor", "asr__speech__recognition__lib_8h.html#a1e20b5b3451447e4d12549801c671144", null ],
    [ "em::asr_speech_recognition_lib::kVersionMinor", "asr__speech__recognition__lib_8h.html#a75a43d1867dd6b762dfb3f7833bea56e", null ],
    [ "em::asr_speech_recognition_lib::kVersionPatch", "asr__speech__recognition__lib_8h.html#ace72e7d33d17745888fbb8dece9d8599", null ]
];