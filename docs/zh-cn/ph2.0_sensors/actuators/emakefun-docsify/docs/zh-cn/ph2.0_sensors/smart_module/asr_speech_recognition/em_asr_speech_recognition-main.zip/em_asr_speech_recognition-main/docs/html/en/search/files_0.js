var searchData=
[
  ['asr_5fspeech_5frecognition_2ecpp_0',['asr_speech_recognition.cpp',['../asr__speech__recognition_8cpp.html',1,'']]],
  ['asr_5fspeech_5frecognition_2eh_1',['asr_speech_recognition.h',['../asr__speech__recognition_8h.html',1,'']]],
  ['asr_5fspeech_5frecognition_5flib_2eh_2',['asr_speech_recognition_lib.h',['../asr__speech__recognition__lib_8h.html',1,'']]]
];
