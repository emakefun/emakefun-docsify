import time
from touch_piano import TouchPiano
KEY1 = 0XFEFE
KEY2 = 0xFDFD
KEY3 = 0xFBFB
KEY4 = 0xF7F7
KEY5 = 0xEFEF
KEY6 = 0xDFDF
KEY7 = 0xBFBF
KEY8 = 0x7F7F
KEY = [KEY1, KEY2, KEY3, KEY4, KEY5, KEY6, KEY7, KEY8]
g_touch_piano = TouchPiano(14,15)

print("Start")

def print_key(key):
    if(g_touch_piano.pressed(key)):
        print(f"KEY{KEY.index(key)+1} pressed")
    elif(g_touch_piano.released(key)):
        print(f"KEY{KEY.index(key)+1}released")
    elif(g_touch_piano.pressing(key)):
        print(f"KEY{KEY.index(key)+1}pressing")

while True:
    g_touch_piano.tick()
    for i in KEY:
        print_key(i)
