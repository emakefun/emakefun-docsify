import machine
import time
class Debouncer:    
    def debounce(self, value):
        if value != self.debouncing_value:
            self.debouncing_value = value
            self.debounce_start_time = time.ticks_ms()
        elif (self.last_value != self.debouncing_value) and (time.ticks_diff(time.ticks_ms(), self.debounce_start_time) >= self.debounce_duration_ms):
            self.last_value = self.debouncing_value
        return self.last_value

    def start(self,debounce_duration_ms,default_last_value):
        self.debounce_duration_ms = debounce_duration_ms
        self.last_value = default_last_value
        self.debouncing_value = default_last_value
        self.debounce_start_time = time.ticks_ms()
        