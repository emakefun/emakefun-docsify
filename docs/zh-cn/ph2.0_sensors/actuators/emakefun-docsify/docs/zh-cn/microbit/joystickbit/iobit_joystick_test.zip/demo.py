from machine import Pin, I2C
from mpython import *
from joystickbit import *
import time
from machine import Timer

joystick_L_X = -1
joystick_L_Y = -1
joystick_R_X = -1
joystick_R_Y = -1
joystick_R = -1
joystick_L = -1
BUTTON_L = -1
BUTTON_R = -1

import music

def on_button_a_pressed(_):
    music.play(music.DADADADUM, wait=False, loop=True)

button_a.event_pressed = on_button_a_pressed

def on_button_b_pressed(_):
    music.stop()

button_b.event_pressed = on_button_b_pressed

# using default address 0x3C
i2c = I2C(0, sda=Pin(23), scl=Pin(22), freq=400000)

# create a JoystickController object
joystick = JoystickController(i2c=i2c)
p1 = MPythonPin(1, PinMode.OUT)

def timer1_tick(_):
    global joystick_L, joystick_R, BUTTON_L, BUTTON_R, joystick_L_X, joystick_L_Y, joystick_R_X, joystick_R_Y
    joystick_R = joystick.get_button_status(JOYSTICK_BUTTON_RIGHT)
    joystick_L = joystick.get_button_status(JOYSTICK_BUTTON_LEFT)
    BUTTON_L = joystick.get_button_status(BUTTON_LEFT_REG)
    BUTTON_R = joystick.get_button_status(BUTTON_RIGHT_REG)
    if (joystick_R == Button_Status.JOYSTICK_SINGLE_CLICK):
        p1.write_digital(1)
    if (joystick_L == Button_Status.JOYSTICK_SINGLE_CLICK):
        p1.write_digital(0)
    if (BUTTON_R == Button_Status.JOYSTICK_SINGLE_CLICK):
        rgb.fill((int(255), int(0), int(0)))
        rgb.write()
    if (BUTTON_R == Button_Status.JOYSTICK_DOUBLE_CLICK):
        rgb.fill((int(0), int(0), int(0)))
        rgb.write()
    if (BUTTON_L == Button_Status.JOYSTICK_SINGLE_CLICK):
        rgb.fill((int(0), int(255), int(0)))
        rgb.write()
    pass


tim1 = Timer(1)

tim1.init(period=10, mode=Timer.PERIODIC, callback=timer1_tick)
oled.fill(0)
oled.text("jstL x:    y:   ", 0, 0, 1)
oled.text("jstR x:    y:   ", 0, 16, 1)

while True:
    oled.fill_rect(56, 0, 32, 16, 0)  #清空对应位置
    oled.fill_rect(104, 0, 32, 16, 0)
    oled.fill_rect(56, 16, 32, 16, 0)
    oled.fill_rect(104, 16, 32, 16, 0)
    oled.text(str(joystick.read_joystick_left_x()), 8*7, 0, 1)
    oled.text(str(joystick.read_joystick_left_y()), 8*13, 0, 1)
    oled.text(str(joystick.read_joystick_right_x()), 8*7, 16, 1)
    oled.text(str(joystick.read_joystick_right_y()), 8*13, 16, 1)
    oled.show()
