from stepper_motor import *

motor = Stepper(pin0, pin1, pin2, pin8)

motor.run(180, 1) # 逆时针转动180度
motor.run(180, -1) # 顺时针转动180度
motor.stop() # 停止转动