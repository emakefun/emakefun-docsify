from microbit import *

# 关闭microbit的显示器，以释放被其占用的引脚
display.off()

# 半步励磁
HALF_STEP = [
    [0, 0, 0, 1],
    [0, 0, 1, 1],
    [0, 0, 1, 0],
    [0, 1, 1, 0],
    [0, 1, 0, 0],
    [1, 1, 0, 0],
    [1, 0, 0, 0],
    [1, 0, 0, 1],
]


class Stepper():
    def __init__(self, pin_1, pin_2, pin_3, pin_4, delay=5):
        self.pin_1 = pin_1
        self.pin_2 = pin_2
        self.pin_3 = pin_3
        self.pin_4 = pin_4
        
        self.delay = delay
        
        self.reset()

    def run(self, angle ,direction=1):
        """ direction = -1 时顺时针转动"""
        for i in range (round(angle / 180 *256)):
            for x in range (8):
                for bit in HALF_STEP[::direction]:
                    self.pin_1.write_digital(bit[0])
                    self.pin_2.write_digital(bit[1])
                    self.pin_3.write_digital(bit[2])
                    self.pin_4.write_digital(bit[3])
                    sleep(self.delay)
        self.stop()

    def stop(self):
        self.pin_1.write_digital(0)
        self.pin_2.write_digital(0)
        self.pin_3.write_digital(0)
        self.pin_4.write_digital(0)
