import machine
import time
from stepper_motor import StepperMotor

stepper_motor = StepperMotor(pin_a=machine.Pin(17, machine.Pin.OUT),
                             pin_b=machine.Pin(16, machine.Pin.OUT),
                             pin_c=machine.Pin(15, machine.Pin.OUT),
                             pin_d=machine.Pin(14, machine.Pin.OUT))

stepper_motor.excitation = StepperMotor.HALF_PHASE_EXCITATION  #设置相位激励模式
stepper_motor.rpm = 10  #设置速度，速度不宜过快，否则会丢步无法转动，单位RPM
position = 360  #旋转角度，360为1圈
print_time = time.ticks_ms()

while True:
    stepper_motor.tick()
    #position = position + 1
    if stepper_motor.reached_target_position:  #如果到达目标位置
        position = -position  #反向
        stepper_motor.rotate(position)  #相对于当前位置移动{position}度
        
    if time.ticks_ms() - print_time > 100:  #每隔一段时间打印当前位置
        print_time = time.ticks_ms()
        print(stepper_motor.current_position)

