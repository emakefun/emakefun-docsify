/**
 * @file hx711_lcd1602_display.ino
 * @brief HX711 称重 + LCD1602 实时显示（保留三位小数）
 *
 * 硬件连接：
 *   HX711  DT(数据)   → Arduino D9
 *   HX711  SCK(时钟)  → Arduino A0
 *   HX711  VCC        → 5V
 *   HX711  GND        → GND
 *
 *   LCD1602(I2C) SDA  → Arduino A4
 *   LCD1602(I2C) SCL  → Arduino A5
 *   LCD1602  VCC      → 5V
 *   LCD1602  GND      → GND
 *
 *   去皮按钮 S(信号)  → Arduino A2 （另一端接 GND，按下拉低）
 *
 * 功能：上电自动去皮 → 屏幕实时显示重量（12.345 g）→ 按 A2 按钮随时重新去皮
 */

#include "HX711.h"
#include "LiquidCrystal_I2C.h"
#include <stdlib.h>                     // dtostrf() 声明在这个头文件里

#define DATA_PIN          9
#define CLOCK_PIN         A0
#define TARE_BUTTON_PIN   A2
#define SCALE_VALUE       -385.081061   // 校准值（已含 1.32% 增益修正）

LiquidCrystal_I2C lcd(0x27, 16, 2);     // I2C地址0x27，16列2行（屏幕全黑可改0x3F）
HX711 scale;

const uint8_t  kReadTimes  = 10;        // 每次读数内部采样次数
const uint8_t  kWindowSize = 5;         // 滑动平均窗口
const uint16_t kIntervalMs = 300;       // 刷新间隔
const uint16_t kDebounceMs = 30;        // 按钮消抖时间

float window[kWindowSize];
uint8_t index  = 0;
uint8_t filled = 0;

void setup() {
  Serial.begin(115200);

  // 去皮按钮：内部上拉，不按为高电平，按下为低电平
  pinMode(TARE_BUTTON_PIN, INPUT_PULLUP);

  // 初始化屏幕
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("  HX711 Scale   ");

  // 初始化称重模块
  scale.begin(DATA_PIN, CLOCK_PIN);
  scale.wait_ready();
  scale.set_average_mode();
  scale.set_scale(SCALE_VALUE);

  lcd.setCursor(0, 1);
  lcd.print("  Taring...     ");
  scale.tare(30);                       // 上电自动去皮，此时托盘要空

  for (uint8_t i = 0; i < kWindowSize; i++) window[i] = 0.0f;

  Serial.println("HX711 + LCD1602 就绪");
}

void loop() {
  // ---------- 1. 按钮去皮 ----------
  if (digitalRead(TARE_BUTTON_PIN) == LOW) {
    delay(kDebounceMs);
    if (digitalRead(TARE_BUTTON_PIN) == LOW) {
      lcd.setCursor(0, 1);
      lcd.print("  Taring...     ");
      scale.tare(30);
      for (uint8_t i = 0; i < kWindowSize; i++) window[i] = 0.0f;
      filled = 0;
      index  = 0;
      Serial.println("[去皮] 完成");
      while (digitalRead(TARE_BUTTON_PIN) == LOW) delay(10);  // 等待松手
    }
  }

  // ---------- 2. 读取重量 ----------
  float reading = scale.get_units(kReadTimes);

  // 滑动平均，让数字不乱跳
  window[index] = reading;
  index = (index + 1) % kWindowSize;
  if (filled < kWindowSize) filled++;

  float sum = 0.0f;
  for (uint8_t i = 0; i < filled; i++) sum += window[i];
  float weight = sum / filled;

  // 接近零点时归零，避免空载显示 0.005
  if (weight > -0.05f && weight < 0.05f) weight = 0.0f;

  // ---------- 3. 屏幕显示 ----------
  // 注意：AVR 的 printf 不支持 %f，必须用 dtostrf() 把浮点转成字符串
  char num[12];
  dtostrf(weight, 8, 3, num);           // 8字符宽、3位小数，右对齐

  char buf[17];
  int len = snprintf(buf, sizeof(buf), "%s g", num);

  lcd.setCursor(0, 1);
  lcd.print(buf);
  for (uint8_t i = len; i < 16; i++) lcd.print(' ');   // 补空格清掉旧字符

  // ---------- 4. 串口同步输出 ----------
  Serial.print("重量: ");
  Serial.print(weight, 3);
  Serial.println(" g");

  delay(kIntervalMs);
}
