/**
 * @file esay_main.ino
 * @brief HX711称重模块
 *
 * 硬件连接：
 *   HX711 DAT(数据) → Arduino D5
 *   HX711 CLK(时钟) → Arduino D6
 *   VCC → 5V, GND → GND
 */

#include "HX711.h"

#define DATA_PIN  5
#define CLOCK_PIN 6
#define SCALE_VALUE -1092.673828   // 校准值

HX711 scale;

void setup() {
  Serial.begin(115200);
  scale.begin(DATA_PIN, CLOCK_PIN);

  // 等待传感器就绪
  scale.wait_ready();

  // 设置中值滤波
  scale.set_median_mode();

  // 设置校准值
  scale.set_scale(SCALE_VALUE);

  // 自动去皮
  Serial.println("[系统] 初始化HX711...");
  Serial.print("[系统] Scale=");
  Serial.println(SCALE_VALUE, 6);

  scale.tare(20);
  Serial.println("[系统] 去皮完成");

  // 显示offset信息
  Serial.print("[调试] Offset=");
  Serial.println(scale.get_offset());
  Serial.println("[系统] 开始测量\n");
}

void loop() {
  // 获取重量（5次采样）
  float weight = scale.get_units(5);

  // 调试信息
  Serial.print("[测量] 原始值=");
  Serial.print(scale.get_value(5), 2);
  Serial.print(" | 重量=");
  Serial.print(weight, 2);
  Serial.println(" g");

  delay(300);
}
