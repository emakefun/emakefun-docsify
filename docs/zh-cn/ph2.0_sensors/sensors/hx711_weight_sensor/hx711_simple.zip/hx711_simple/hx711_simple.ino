/**
 * @file hx711_simple.ino
 * @brief HX711称重模块
 *
 * 硬件连接：
 *   HX711 DT(数据) → Arduino D9
 *   HX711 SCK(时钟) → Arduino A0
 *   VCC → 5V, GND → GND
 */

#include "HX711.h"

#define DATA_PIN  9
#define CLOCK_PIN A0
#define SCALE_VALUE  -385.081061   // 校准值（已含 1.32% 增益修正）
#define ZERO_TRIM     0.60f        // 零点修正(克)，空载读数是多少就扣掉多少

const uint8_t kReadTimes = 10;
const uint8_t kWindowSize = 5;
const uint16_t kIntervalMs = 500;

HX711 scale;

float window[kWindowSize];
uint8_t index = 0;
uint8_t filled = 0;

void setup() {
  Serial.begin(115200);
  scale.begin(DATA_PIN, CLOCK_PIN);
  scale.wait_ready();
  scale.set_average_mode();
  scale.set_scale(SCALE_VALUE);
  scale.tare(30);                    // 确保托盘完全空置时执行
  for (uint8_t i = 0; i < kWindowSize; i++) window[i] = 0.0f;
  Serial.println("开始精准测量");
}

void loop() {
  float reading = scale.get_units(kReadTimes);

  window[index] = reading;
  index = (index + 1) % kWindowSize;
  if (filled < kWindowSize) filled++;

  float sum = 0.0f;
  for (uint8_t i = 0; i < filled; i++) sum += window[i];
  float weight = sum / filled - ZERO_TRIM;

  Serial.print("重量: ");
  Serial.print(weight, 3);
  Serial.println(" g");

  delay(kIntervalMs);
}
