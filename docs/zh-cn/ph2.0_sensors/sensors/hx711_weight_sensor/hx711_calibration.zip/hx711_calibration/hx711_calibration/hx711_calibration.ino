/**
 * @file main.ino
 * @brief HX711校准+测量一体程序
 *
 * 硬件连接：DAT→D5, CLK→D6, VCC→5V, GND→GND
 * 流程：上电 → 去皮 → 输入已知重量校准 → 自动开始测量
 */

#include "HX711.h"

#define DATA_PIN 5
#define CLOCK_PIN 6

HX711 scale;

void setup() {
  Serial.begin(115200);
  scale.begin(DATA_PIN, CLOCK_PIN);
  scale.wait_ready();
  scale.set_median_mode();

  Serial.println("=== HX711校准 ===\n");

  // 步骤1: 去皮
  Serial.println("1. 移除所有物品，按回车去皮...");
  wait_enter();
  scale.tare(20);
  Serial.println("   去皮完成！\n");

  // 步骤2: 输入已知重量
  Serial.println("2. 放置已知重量(克)，输入数值后按回车:");
  float weight = read_float();
  Serial.print("   已知重量: ");
  Serial.print(weight);
  Serial.println(" g\n");

  // 步骤3: 校准
  Serial.println("3. 正在校准...");
  scale.calibrate_scale(weight, 30);

  Serial.print("\n校准完成！scale=");
  Serial.println(scale.get_scale(), 6);

  // 步骤4: 重新去皮，准备测量
  Serial.println("\n4. 请移除校准重量，按回车开始测量...");
  wait_enter();
  scale.tare(20);

  Serial.println("\n=== 开始测量 ===\n");
}

void loop() {
  float weight = scale.get_units(5);
  Serial.print("重量: ");
  Serial.print(weight, 2);
  Serial.println(" g");
  delay(300);
}

void wait_enter() {
  while (!Serial.available());
  Serial.readStringUntil('\n');
}

float read_float() {
  while (!Serial.available());
  float val = Serial.parseFloat();
  Serial.readStringUntil('\n');
  return val;
}
