import struct
from microbit import *
from micropython import const

_MEMORY_ADDRESS_DEVICE_ID = const(0x00)
_MEMORY_ADDRESS_VERSION = const(0x01)
_MEMORY_ADDRESS_ANALOG_VALUES = const(0x10)
_MEMORY_ADDRESS_DIGITAL_VALUES = const(0x1A)
_MEMORY_ADDRESS_HIGH_THRESHOLDS = const(0x1C)
_MEMORY_ADDRESS_LOW_THRESHOLDS = const(0x26)

class FiveLineTrackerV3:

    def __init__(self, i2c_address=0x50):
        i2c.init()
        self._i2c = i2c
        self._i2c_address = i2c_address

    def device_id(self):
        """
        读取设备ID
        """
        self._i2c.write(self._i2c_address, bytearray([_MEMORY_ADDRESS_DEVICE_ID]))
        return self._i2c.read(self._i2c_address, 1)[0]

    def version(self):
        """
        读取固件版本号
        """
        self._i2c.write(self._i2c_address, bytearray([_MEMORY_ADDRESS_VERSION]))
        return self._i2c.read(self._i2c_address, 1)[0]
    def high_thresholds(self, values=None):
        """
        读取或设置高阈值
        """
    def high_thresholds(self, values=None):
        if values is None:
            # 读取高阈值
            self._i2c.write(self._i2c_address, bytearray([_MEMORY_ADDRESS_HIGH_THRESHOLDS]))
            return struct.unpack(
                "<HHHHH",
                self._i2c.read(self._i2c_address, 10))
        else:
            # 设置高阈值
            self._i2c.write(self._i2c_address, bytes([_MEMORY_ADDRESS_HIGH_THRESHOLDS])+struct.pack("<HHHHH", *values))

    def low_thresholds(self, values=None):
        """
        读取或设置低阈值
        """
        if values is None:
            # 读取低阈值
            self._i2c.write(self._i2c_address, bytearray([_MEMORY_ADDRESS_LOW_THRESHOLDS]))
            return struct.unpack(
                "<HHHHH",
                self._i2c.read(self._i2c_address, 10))
        else:
            # 设置低阈值
            self._i2c.write(self._i2c_address, bytes([_MEMORY_ADDRESS_LOW_THRESHOLDS])+struct.pack("<HHHHH", *values))


    def high_threshold(self, channel, value):
        """
        设置单个高阈值
        """
        self._i2c.write(self._i2c_address, bytes([_MEMORY_ADDRESS_HIGH_THRESHOLDS + (channel << 1)])+struct.pack("<H", value))
    def low_threshold(self, channel, value):
        """
        设置单个低阈值
        """
        self._i2c.write(self._i2c_address, bytearray([_MEMORY_ADDRESS_LOW_THRESHOLDS + (channel << 1)])+struct.pack("<H", value))

    def analog_values(self):
        """
        读取模拟值
        """
        self._i2c.write(self._i2c_address, bytearray([_MEMORY_ADDRESS_ANALOG_VALUES]))
        return struct.unpack(
            "<HHHHH",
            self._i2c.read(self._i2c_address, 10))

    def digital_values(self):
        """
        读取数字值
        """
        self._i2c.write(self._i2c_address, bytearray([_MEMORY_ADDRESS_DIGITAL_VALUES]))
        return self._i2c.read(self._i2c_address, 1)[0]
    def analog_value(self, channel):
        """
        读取单个模拟值
        """
    def analog_value(self, channel):
        return self.analog_values()[channel]

    def digital_value(self, channel):
        """
        读取单个数字值 
        """
        return (self.digital_values() >> channel) & 0x01