#include "dht11.h"  // 导入 DHT11 库

namespace {
constexpr uint8_t kDht11Pin = 3;  // 定义温湿度传感器引脚

dht11 g_dht;  // 创建 DHT11 对象
}  // namespace

void setup() {
  Serial.begin(115200);  // 设置串口波特率
}

void loop() {
  g_dht.read(kDht11Pin);  // 读取温湿度数据

  Serial.print("Tep: ");
  Serial.print(static_cast<float>(g_dht.temperature));  // 打印温度
  Serial.print("C");
  Serial.print("     Hum: ");
  Serial.print(static_cast<float>(g_dht.humidity));  // 打印湿度
  Serial.println("%");

  delay(200);
}