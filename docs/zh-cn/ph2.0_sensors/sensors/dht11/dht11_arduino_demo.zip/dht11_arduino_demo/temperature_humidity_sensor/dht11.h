#pragma once

#ifndef _DHT11_H_
#define _DHT11_H_

#if defined(ARDUINO) && (ARDUINO >= 100)
#include <Arduino.h>
#else
#include <WProgram.h>
#endif

class dht11 {
 public:
  enum class ErrorCode : uint32_t {
    kOK = 0,
    kChecksum = 1,
    kTimeout = 2,
  };
  int16_t humidity = 0;
  int16_t temperature = 0;

  ErrorCode read(const uint8_t pin);
};
#endif
