#include "dht11.h"

dht11::ErrorCode dht11::read(const uint8_t pin) {
  // BUFFER TO RECEIVE
  uint8_t bits[5];
  uint8_t cnt = 7;
  uint8_t idx = 0;

  // EMPTY BUFFER
  for (uint8_t i = 0; i < 5; i++) {
    bits[i] = 0;
  }

  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
  delay(18);
  digitalWrite(pin, HIGH);
  delayMicroseconds(40);
  pinMode(pin, INPUT);

  uint32_t loop_cnt = 10000;
  while (digitalRead(pin) == LOW) {
    if (loop_cnt-- == 0) {
      return ErrorCode::kTimeout;
    }
  }

  loop_cnt = 10000;
  while (digitalRead(pin) == HIGH) {
    if (loop_cnt-- == 0) {
      return ErrorCode::kTimeout;
    }
  }

  for (uint8_t i = 0; i < 40; i++) {
    loop_cnt = 10000;
    while (digitalRead(pin) == LOW) {
      if (loop_cnt-- == 0) {
        return ErrorCode::kTimeout;
      }
    }

    uint32_t time_value = micros();

    loop_cnt = 10000;

    while (digitalRead(pin) == HIGH) {
      if (loop_cnt-- == 0) {
        return ErrorCode::kTimeout;
      }
    }

    if ((micros() - time_value) > 40) {
      bits[idx] |= (1 << cnt);
    }
    if (cnt == 0) {
      cnt = 7;  // restart at MSB
      idx++;    // next byte!
    } else
      cnt--;
  }

  humidity = bits[0];
  temperature = bits[2];

  uint8_t sum = bits[0] + bits[2];

  if (bits[4] != sum) {
    return ErrorCode::kChecksum;
  }
  return ErrorCode::kOK;
}