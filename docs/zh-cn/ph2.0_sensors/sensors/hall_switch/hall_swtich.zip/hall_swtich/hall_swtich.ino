#define DIGITAL_PIN 7  // 霍尔信号引脚
int digital_value = 0;
void setup() {
  Serial.begin(9600);
  pinMode(DIGITAL_PIN, INPUT);
}
void loop() {
  digital_value = digitalRead(DIGITAL_PIN);
  Serial.print("HallSensor Digital:");
  Serial.println(digital_value);
  delay(200);
}