from ir_remote_control_receiver import IRRemoteControlReceiver
import time

print('setup')

ir_receiver = IRRemoteControlReceiver(pin=4)

button_str_dict = {
    IRRemoteControlReceiver.BUTTON_0: "Button 0",
    IRRemoteControlReceiver.BUTTON_1: "Button 1",
    IRRemoteControlReceiver.BUTTON_2: "Button 2",
    IRRemoteControlReceiver.BUTTON_3: "Button 3",
    IRRemoteControlReceiver.BUTTON_4: "Button 4",
    IRRemoteControlReceiver.BUTTON_5: "Button 5",
    IRRemoteControlReceiver.BUTTON_6: "Button 6",
    IRRemoteControlReceiver.BUTTON_7: "Button 7",
    IRRemoteControlReceiver.BUTTON_8: "Button 8",
    IRRemoteControlReceiver.BUTTON_9: "Button 9",
    IRRemoteControlReceiver.BUTTON_POWER: "Button Power",
    IRRemoteControlReceiver.BUTTON_MENU: "Button Menu",
    IRRemoteControlReceiver.BUTTON_TEST: "Button Test",
    IRRemoteControlReceiver.BUTTON_PLAY: "Button Play",
    IRRemoteControlReceiver.BUTTON_VOLUME_UP: "Button Volume Up",
    IRRemoteControlReceiver.BUTTON_VOLUME_DOWN: "Button Volume Down",
    IRRemoteControlReceiver.BUTTON_PREVIOUS_PAGE: "Button previous page",
    IRRemoteControlReceiver.BUTTON_NEXT_PAGE: "Button Next page",
    IRRemoteControlReceiver.BUTTON_BACK: "Button Back",
    IRRemoteControlReceiver.BUTTON_C: "Button C"
}

print('loop')
while True:
    ir_receiver.receive()
    for button, button_str in button_str_dict.items():
        if ir_receiver.pressed(button):
            print(button_str, 'pressed')
        if ir_receiver.released(button):
            print(button_str, 'released')
        if ir_receiver.pressing(button):
            print(button_str, 'pressing')
    time.sleep_ms(50)
