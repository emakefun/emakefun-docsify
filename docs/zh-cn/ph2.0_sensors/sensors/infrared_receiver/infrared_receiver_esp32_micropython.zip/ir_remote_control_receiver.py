import machine
import struct
import time
from micropython import const


class IRRemoteControlReceiver:
    BUTTON_NONE = const(0)
    BUTTON_0 = const(1 << 0)
    BUTTON_1 = const(1 << 1)
    BUTTON_2 = const(1 << 2)
    BUTTON_3 = const(1 << 3)
    BUTTON_4 = const(1 << 4)
    BUTTON_5 = const(1 << 5)
    BUTTON_6 = const(1 << 6)
    BUTTON_7 = const(1 << 7)
    BUTTON_8 = const(1 << 8)
    BUTTON_9 = const(1 << 9)
    BUTTON_POWER = const(1 << 10)
    BUTTON_B = const(1 << 11)
    BUTTON_MENU = const(1 << 12)
    BUTTON_TEST = const(1 << 13)
    BUTTON_PLAY = const(1 << 14)
    BUTTON_VOLUME_UP = const(1 << 15)
    BUTTON_VOLUME_DOWN = const(1 << 16)
    BUTTON_PREVIOUS_PAGE = const(1 << 17)
    BUTTON_NEXT_PAGE = const(1 << 18)
    BUTTON_BACK = const(1 << 19)
    BUTTON_C = const(1 << 20)

    CODE_MAP = {
        0x00: BUTTON_NONE,
        0x16: BUTTON_0,
        0x0C: BUTTON_1,
        0x18: BUTTON_2,
        0x5E: BUTTON_3,
        0x08: BUTTON_4,
        0x1C: BUTTON_5,
        0x5A: BUTTON_6,
        0x42: BUTTON_7,
        0x52: BUTTON_8,
        0x4A: BUTTON_9,
        0x45: BUTTON_POWER,
        # 0x46: BUTTON_B,
        0x47: BUTTON_MENU,
        0x44: BUTTON_TEST,
        0x15: BUTTON_PLAY,
        0x40: BUTTON_VOLUME_UP,
        0x19: BUTTON_VOLUME_DOWN,
        0x07: BUTTON_PREVIOUS_PAGE,
        0x09: BUTTON_NEXT_PAGE,
        0x43: BUTTON_BACK,
        0x0D: BUTTON_C,
    }

    _receivers = dict()

    def __init__(self, pin) -> None:
        self.pin = machine.Pin(pin, machine.Pin.IN, pull=machine.Pin.PULL_UP)
        IRRemoteControlReceiver._receivers[self.pin] = self
        self.pin.irq(trigger=machine.Pin.IRQ_FALLING,
                     handler=IRRemoteControlReceiver._on_falling_callback)
        self.last_falling_time = time.ticks_us()
        self.bits: int = 0
        self.code: int = 0
        self.falling_count = 0
        self.button_state = 0
        self.last_button_state = 0

    def _on_falling_callback(pin):
        IRRemoteControlReceiver._receivers[pin]._on_falling()

    def _on_falling(self):
        now = time.ticks_us()
        if time.ticks_diff(now, self.last_falling_time) > 45000:
            self.bits = 0
            self.falling_count = 0
        else:
            self.falling_count += 1

        if self.falling_count >= 2 and self.falling_count <= 33:
            self.bits = self.bits | ((1 if time.ticks_diff(
                now, self.last_falling_time) > 1685 else 0) <<
                                     (self.falling_count - 2))
            if self.falling_count == 33:
                data = struct.pack("<I", self.bits)
                if data[0] == ~data[1] & 0xFF and data[2] == ~data[3] & 0xFF:
                    self.code = data[2]

        self.last_falling_time = now

    def receive(self) -> None:
        self.last_button_state = self.button_state
        if time.ticks_diff(time.ticks_us(), self.last_falling_time) > 100000:
            self.code = 0
            self.button_state = 0

        if self.code in IRRemoteControlReceiver.CODE_MAP:
            self.button_state = IRRemoteControlReceiver.CODE_MAP[self.code]
        else:
            self.button_state = 0

    def pressed(self, button):
        return self.last_button_state & button == 0 and self.button_state & button != 0

    def released(self, button):
        return self.button_state & button == 0 and self.last_button_state & button != 0

    def pressing(self, button):
        return self.button_state & button != 0
