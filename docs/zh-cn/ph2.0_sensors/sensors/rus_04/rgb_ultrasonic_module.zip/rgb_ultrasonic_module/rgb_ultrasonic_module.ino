#include <Wire.h>  // 导入通信库

#include "rgb_ultrasonic.h"  // 导入 RGB 超声波库

namespace {
constexpr uint8_t kIoPin = 6;   // 定义 RGB 超声波 IO 引脚
constexpr uint8_t kRgbPin = 5;  // 定义 RGB 超声波 RGB 引脚

RgbUltrasonic g_rus04(kIoPin, kRgbPin);  // 创建 RGB 超声波对象
float g_distance = 0.0;                  // 存储测距数据（单位：cm）
}  // namespace

void setup() {
  Serial.begin(115200);
  g_rus04.SetRgbIndexColor(1, 3, RGB_GREEN);
  g_rus04.SetRgbIndexColor(4, 6, RGB_BLUE);
}

void loop() {
  g_distance = g_rus04.GetUltrasonicDistance();  // 获取 RGB 超声波所测距离

  Serial.print(g_distance);  // 打印距离值
  Serial.println("cm");
  delay(100);
}