#include "rgb_ultrasonic.h"

RgbUltrasonic::RgbUltrasonic(byte signal_pin, byte rgb_pin) {
  signal_pin_ = signal_pin;
  rgb_pin_ = rgb_pin;
  my_rgb = new RGBLed(rgb_pin_, 6);
}

float RgbUltrasonic::GetUltrasonicDistance(void) {
  delayMicroseconds(20);

  uint32_t time_echo_us = 0;

  pinMode(signal_pin_, OUTPUT);
  digitalWrite(signal_pin_, HIGH);
  delayMicroseconds(10);
  digitalWrite(signal_pin_, LOW);
  pinMode(signal_pin_, INPUT);

  time_echo_us = pulseIn(signal_pin_, HIGH, 500000);
  if ((time_echo_us < 60000) && (time_echo_us > 1)) {
    front_distance = pulseIn(signal_pin_, HIGH, 500000) / 58.00;
  }
  return front_distance;
}

void RgbUltrasonic::SetRgbIndexColor(const uint8_t start_index, const uint8_t end_index, const int32_t color) {
  for (uint8_t i = start_index; i <= end_index; i++) {
    my_rgb->setColor(i, color);
  }
  my_rgb->show();
}

void RgbUltrasonic::SetRgbEffect(const E_RGB_INDEX index, const int32_t color, const uint8_t effect) {
  uint8_t start = 1;
  uint8_t end = 6;

  if (index == E_RGB_RIGHT) {
    start = 4;
    end = 6;
  } else if (index == E_RGB_LEFT) {
    start = 1;
    end = 3;
  }

  switch ((E_RGB_EFFECT)effect) {
    case E_EFFECT_NONE:
      SetRgbIndexColor(start, end, color);
      break;

    case E_EFFECT_BREATHING:
      for (uint16_t i = 0; i < 256; i++) {
        my_rgb->setBrightness(i);
        SetRgbIndexColor(start, end, color);
        delay((i < 20) ? 60 : (255 / i));
      }
      for (uint16_t i = 255; i >= 0; i--) {
        my_rgb->setBrightness(i);
        SetRgbIndexColor(start, end, color);
        delay((i < 20) ? 60 : (255 / i));
      }
      my_rgb->setBrightness(255);
      break;

    case E_EFFECT_ROTATE:
      for (byte i = 0; i < 4; i++) {
        my_rgb->setColor(start, color);
        my_rgb->setColor(start + 1, 0);
        my_rgb->setColor(start + 2, 0);

        if (index == E_RGB_ALL) {
          my_rgb->setColor(end - 2, color);
          my_rgb->setColor(end - 1, 0);
          my_rgb->setColor(end, 0);
        }

        my_rgb->show();
        delay(150);
        my_rgb->setColor(start, 0);
        my_rgb->setColor(start + 1, color);
        my_rgb->setColor(start + 2, 0);

        if (index == E_RGB_ALL) {
          my_rgb->setColor(end - 2, 0);
          my_rgb->setColor(end - 1, color);
          my_rgb->setColor(end, 0);
        }

        my_rgb->show();
        delay(150);
        my_rgb->setColor(start, 0);
        my_rgb->setColor(start + 1, 0);
        my_rgb->setColor(start + 2, color);
        if (index == E_RGB_ALL) {
          my_rgb->setColor(end - 2, 0);
          my_rgb->setColor(end - 1, 0);
          my_rgb->setColor(end, color);
        }
        my_rgb->show();
        delay(150);
      }
      SetRgbIndexColor(1, 6, 0);
      break;

    case E_EFFECT_FLASH:
      for (uint8_t i = 0; i < 6; i++) {
        SetRgbIndexColor(start, end, color);
        delay(150);
        SetRgbIndexColor(start, end, 0);
        delay(150);
      }
      break;
  }
}
