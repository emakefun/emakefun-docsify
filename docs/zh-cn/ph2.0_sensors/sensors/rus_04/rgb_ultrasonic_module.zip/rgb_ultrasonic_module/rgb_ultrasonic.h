#ifndef _RGBULTRASONIC_H_
#define _RGBULTRASONIC_H_

/* Includes ------------------------------------------------------------------*/
#include <Arduino.h>

#include "RGBLed.h"

#define UL_LIMIT_MIN 5
#define UL_LIMIT_MID 10
#define UL_LIMIT_MAX 400

#define RGB_RED 0xFF0000
#define RGB_GREEN 0x00FF00
#define RGB_BLUE 0x0000FF
#define RGB_YELLOW 0xFFFF00
#define RGB_PURPLE 0xFF00FF
#define RGB_ORANGE 0xFFA500
#define RGB_INDIGO 0x4b0082
#define RGB_VIOLET 0x8a2be2
#define RGB_WHITE 0xFFFFFF
#define RGB_BLACK 0

typedef enum { E_RGB_ALL = 0, E_RGB_RIGHT = 1, E_RGB_LEFT = 2 } E_RGB_INDEX;

typedef enum { E_EFFECT_NONE = 0, E_EFFECT_BREATHING = 1, E_EFFECT_ROTATE = 2, E_EFFECT_FLASH = 3 } E_RGB_EFFECT;

class RgbUltrasonic {
 public:
  RGBLed* my_rgb;
  float front_distance;

  RgbUltrasonic(const byte signal_pin, const byte rgb_pin);
  float GetUltrasonicDistance(void);
  void SetRgbIndexColor(const uint8_t start_index, const uint8_t end_index, const int32_t color);
  void SetRgbEffect(const E_RGB_INDEX index, const int32_t color, const uint8_t effect = E_EFFECT_NONE);

 private:
  RgbUltrasonic(const RgbUltrasonic&) = delete;

  RgbUltrasonic& operator=(const RgbUltrasonic&) = delete;

  byte signal_pin_;
  byte rgb_pin_;
};

#endif
