#include "RgbUltrasonic.h"

RgbUltrasonic::RgbUltrasonic(byte signal_pin)
{
    SignalPin = signal_pin;
}

float RgbUltrasonic::GetUltrasonicDistance(void)
{
  delayMicroseconds(20);
  unsigned long Time_Echo_us = 0;
  pinMode(SignalPin, OUTPUT);
  digitalWrite(SignalPin, HIGH);
  delayMicroseconds(100);
  digitalWrite(SignalPin, LOW);
  pinMode(SignalPin, INPUT);
  Time_Echo_us = pulseIn(SignalPin, HIGH, 500000);
  if((Time_Echo_us < 60000) && (Time_Echo_us > 1)){
    FrontDistance = Time_Echo_us / 58.00;
  }
  return FrontDistance;
}
