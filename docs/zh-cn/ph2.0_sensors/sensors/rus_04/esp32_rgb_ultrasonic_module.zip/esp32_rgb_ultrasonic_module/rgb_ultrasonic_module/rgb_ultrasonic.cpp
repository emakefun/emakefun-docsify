#include "rgb_ultrasonic.h"

RgbUltrasonic::RgbUltrasonic(const byte signal_pin) {
  signal_pin_ = signal_pin;
}

float RgbUltrasonic::GetUltrasonicDistance(void) {
  delayMicroseconds(20);

  uint32_t time_echo_us = 0;

  pinMode(signal_pin_, OUTPUT);
  digitalWrite(signal_pin_, HIGH);
  delayMicroseconds(100);
  digitalWrite(signal_pin_, LOW);
  pinMode(signal_pin_, INPUT);

  time_echo_us = pulseIn(signal_pin_, HIGH, 500000);
  if ((time_echo_us < 60000) && (time_echo_us > 1)) {
    front_distance = time_echo_us / 58.00;
  }
  return front_distance;
}
