#include <Wire.h>

#include "Adafruit_NeoPixel.h"
#include "rgb_ultrasonic.h"

namespace {
constexpr uint8_t kIoPin = 14;   // RGB超声波 IO引脚
constexpr uint8_t kRgbPin = 12;  // RGB超声波 RGB引脚

constexpr uint8_t kNumLeds = 4;  // NeoPixel 灯珠数量（原代码为4，但后续设置了0~5共6个，保留原逻辑）

Adafruit_NeoPixel g_rgbDisplay(kNumLeds, kRgbPin, NEO_GRB + NEO_KHZ800);
RgbUltrasonic g_rus04(kIoPin);  // 创建RGB超声波对象

uint16_t g_distance = 0;  // 存储超声波测距数据（cm）
}  // namespace

void setup() {
  Serial.begin(115200);

  g_rgbDisplay.begin();

  for (uint8_t i = 0; i < 6; i++) {
    g_rgbDisplay.setPixelColor(i, 0xff0000);
  }
  g_rgbDisplay.show();
  delay(1000);

  // 绿灯
  for (uint8_t i = 0; i < 6; i++) {
    g_rgbDisplay.setPixelColor(i, 0x00ff00);
  }
  g_rgbDisplay.show();
  delay(1000);

  // 蓝灯
  for (uint8_t i = 0; i < 6; i++) {
    g_rgbDisplay.setPixelColor(i, 0x0000ff);
  }
  g_rgbDisplay.show();
  delay(1000);
}

void loop() {
  g_distance = g_rus04.GetUltrasonicDistance();
  Serial.print("Distance is: ");
  Serial.print(g_distance);
  Serial.println("cm");

  delay(300);
}