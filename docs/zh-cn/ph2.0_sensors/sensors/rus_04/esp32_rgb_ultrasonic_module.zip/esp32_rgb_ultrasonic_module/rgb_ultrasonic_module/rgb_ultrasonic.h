#ifndef _RGBULTRASONIC_H_
#define _RGBULTRASONIC_H_

/* Includes ------------------------------------------------------------------*/
#include <Arduino.h>

class RgbUltrasonic {
 public:
  float front_distance;

  RgbUltrasonic(const byte signal_pin);
  float GetUltrasonicDistance(void);

 private:
  RgbUltrasonic(const RgbUltrasonic&) = delete;

  RgbUltrasonic& operator=(const RgbUltrasonic&) = delete;

  byte signal_pin_;
};
#endif
