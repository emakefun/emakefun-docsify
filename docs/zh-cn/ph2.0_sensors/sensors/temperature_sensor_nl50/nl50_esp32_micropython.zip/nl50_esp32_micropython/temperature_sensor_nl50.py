from machine import ADC


class TemperatureSensorNL50:
    def __init__(self, analog_pin) -> None:
        self._adc = ADC(analog_pin)
        self._adc.atten(ADC.ATTN_6DB)
        self._adc.width(ADC.WIDTH_12BIT)

    def get_temperature(self):
        return (((self._adc.read()/4095)*2.2 - 0.5) *100)
