from temperature_sensor_nl50 import TemperatureSensorNL50
import time


temperature_sensor_nl50 = TemperatureSensorNL50(34)


while True:
    temperature = temperature_sensor_nl50.get_temperature()
    print(f"The current temperature is: {temperature:.2f} ℃")
    time.sleep(0.5)
