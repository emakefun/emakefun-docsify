int pin = A0;  //定义传感器引脚

float NL50_read_temperature() {
    int raw_value = analogRead(pin);
    Serial.print("ADC:");
    Serial.println(raw_value);
    float voltage = (raw_value / 1023.0) * 5; // 5V电源 读取ADC值
    Serial.print("voltage:");
    Serial.println(voltage);
    float temperature = (voltage - 0.5) * 100; //  减去0.5V偏置电压 10mV/℃
    return temperature;
}

void setup() {
    Serial.begin(115200);
    Serial.println("Temperature sensor setup");
}

void loop() {
    float temp = NL50_read_temperature();
    Serial.print("Temperature: ");
    Serial.print(temp);
    Serial.println(" °C");
    delay(100);
}