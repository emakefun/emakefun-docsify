int adc_pin = 34;  //定义传感器引脚

float NL50_read_temperature() {
    float calibrate_mv = analogReadMilliVolts(adc_pin);
    float temperature = (calibrate_mv - 500) / 10; //  减去0.5V偏置电压 10mV/℃
    return temperature;
}

void setup() {
    Serial.begin(115200);
    analogSetAttenuation(ADC_6db); //对于这种热敏传感器衰减挡位越低越好 ADC_6db 对应量程2.2V
    Serial.println("Temperature sensor setup");
}

void loop() {
    float temp = NL50_read_temperature();
    Serial.print("Temperature: ");
    Serial.print(temp);
    Serial.println(" °C");
    delay(100);
}