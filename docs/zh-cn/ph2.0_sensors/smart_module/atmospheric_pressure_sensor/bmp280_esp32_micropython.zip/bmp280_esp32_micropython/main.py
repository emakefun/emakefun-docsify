import bmp280
from machine import Pin, I2C

# 初始化BMP280，I2C接口2
BMP = bmp280.BMP280(I2C(0, sda=Pin(21), scl=Pin(22)))

# 测量结果
Tem = BMP.getTemp()
Pre = BMP.getPress()
Alt = BMP.getAltitude()

print(f"Temperature: {Tem} °C, Pressure: {Pre} hPa, Altitude: {Alt} m")
