from gesture_recognizer import GestureRecognizer
from microbit import *

print("setup")
gesture_recognizer = GestureRecognizer(i2c_address=0x39)

print("version:", gesture_recognizer.version)

gesture_dict = {
    GestureRecognizer.GESTURE_NONE: "gesture none",
    GestureRecognizer.GESTURE_RIGHT_SWIPE: "gesture right swipe",
    GestureRecognizer.GESTURE_LEFT_SWIPE: "gesture left swipe",
    GestureRecognizer.GESTURE_BACKWARD_SWIPE: "gesture backward swipe",
    GestureRecognizer.GESTURE_FORWARD_SWIPE: "gesture forward swipe",
    GestureRecognizer.GESTURE_UPWARD: "gesture upward",
    GestureRecognizer.GESTURE_DOWNWARD: "gesture downward",
    GestureRecognizer.GESTURE_OUT_OF_RANGE: "gesture out of range",
    GestureRecognizer.GESTURE_HOVER: "gesture hover",
}

print("loop")
while True:
    gesture = gesture_recognizer.gesture()

    if gesture is not GestureRecognizer.GESTURE_NONE:
        print(gesture_dict[gesture])
