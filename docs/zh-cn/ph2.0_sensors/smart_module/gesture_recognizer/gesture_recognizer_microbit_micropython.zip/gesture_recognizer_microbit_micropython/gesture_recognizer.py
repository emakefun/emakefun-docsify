from micropython import const
from microbit import i2c

class GestureRecognizer:
    DEFAULT_I2C_ADDRESS = const(0x39)

    GESTURE_NONE = const(0x00)
    GESTURE_RIGHT_SWIPE = const(0x01)
    GESTURE_LEFT_SWIPE = const(0x02)
    GESTURE_BACKWARD_SWIPE = const(0x03)
    GESTURE_FORWARD_SWIPE = const(0x04)
    GESTURE_UPWARD = const(0x05)
    GESTURE_DOWNWARD = const(0x06)
    GESTURE_OUT_OF_RANGE = const(0x07)
    GESTURE_HOVER = const(0x08)

    def __init__(self,  i2c_address=DEFAULT_I2C_ADDRESS) -> None:
        i2c.init()
        self._i2c_address = i2c_address

    # @property
    def gesture(self):
        i2c.write(self._i2c_address, bytes([0x01]))
        return i2c.read(self._i2c_address, 1)[0]

    # @property
    def version(self):
        i2c.write(self._i2c_address, bytes([0x00]))
        return i2c.read(self._i2c_address, 1)[0]
