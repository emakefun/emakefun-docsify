from micropython import const


class GestureRecognizer:
    DEFAULT_I2C_ADDRESS: int = const(0x39)

    GESTURE_NONE: int = const(0x00)
    GESTURE_RIGHT_SWIPE: int = const(0x01)
    GESTURE_LEFT_SWIPE: int = const(0x02)
    GESTURE_BACKWARD_SWIPE: int = const(0x03)
    GESTURE_FORWARD_SWIPE: int = const(0x04)
    GESTURE_UPWARD: int = const(0x05)
    GESTURE_DOWNWARD: int = const(0x06)
    GESTURE_OUT_OF_RANGE: int = const(0x07)
    GESTURE_HOVER: int = const(0x08)

    def __init__(self, i2c, i2c_address=DEFAULT_I2C_ADDRESS) -> None:
        self._i2c = i2c
        self._i2c_address = i2c_address

    @property
    def gesture(self):
        self._i2c.writeto(self._i2c_address, bytes([0x01]))
        return self._i2c.readfrom(self._i2c_address, 1)[0]

    @property
    def version(self):
        self._i2c.writeto(self._i2c_address, bytes([0x00]))
        return self._i2c.readfrom(self._i2c_address, 1)[0]
