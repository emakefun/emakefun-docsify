import struct
from micropython import const


class ColorSensorNlcs11:
    DEFAULT_I2C_ADDRESS: int = const(0x43)
    VERSION_MAJOR: int = const(2)
    VERSION_MINOR: int = const(0)
    VERSION_PATCH: int = const(0)
    _MAX_RAW_R: int = const(500)
    _MAX_RAW_G: int = const(1100)
    _MAX_RAW_B: int = const(800)

    def __init__(self, i2c, i2c_address=DEFAULT_I2C_ADDRESS):
        self.i2c = i2c
        self._i2c_address = i2c_address
        self.i2c.writeto(self._i2c_address, b"\x80\x03")

    def _map(self, value, color_c):
        if color_c == 0:
            return 0
        else:
            return round(value / color_c * 255)

    def get_color(self):
        value = struct.unpack(
            "<HHHH", self.i2c.readfrom_mem(self._i2c_address, 0xA0, 8)
        )
        return (
            self._map(value[0], value[3]),
            self._map(value[1], value[3]),
            self._map(value[2], value[3]),
        )
