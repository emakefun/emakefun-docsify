import time
from machine import Pin, I2C
from color_sensor_nlcs11 import ColorSensorNlcs11


i2c = I2C(0, sda=Pin(21), scl=Pin(22))
color_sensor = ColorSensorNlcs11(i2c=i2c)


while True:
    color = color_sensor.get_color()
    print(f"r:{color[0]} g:{color[1]} b:{color[2]}")
    time.sleep(0.2)
