var searchData=
[
  ['initialize_0',['Initialize',['../classemakefun_1_1_color_sensor.html#a91531f99f7f4c4e0cfa7bfc6fd0f124b',1,'emakefun::ColorSensor']]]
];
