var searchData=
[
  ['ki2cdatatoolongtofitintransmitbuffer_0',['kI2cDataTooLongToFitInTransmitBuffer',['../classemakefun_1_1_color_sensor.html#a37a8d07c0d1c694de4700004660b0271abf7340c29a011db5ebbe8c9ad77aa385',1,'emakefun::ColorSensor']]],
  ['ki2cothererror_1',['kI2cOtherError',['../classemakefun_1_1_color_sensor.html#a37a8d07c0d1c694de4700004660b0271ad02f3e32e14a2172a0e3aa808f74ca6c',1,'emakefun::ColorSensor']]],
  ['ki2creceivednackontransmitofaddress_2',['kI2cReceivedNackOnTransmitOfAddress',['../classemakefun_1_1_color_sensor.html#a37a8d07c0d1c694de4700004660b0271a5e9aa58a1a872442291aef244116bc75',1,'emakefun::ColorSensor']]],
  ['ki2creceivednackontransmitofdata_3',['kI2cReceivedNackOnTransmitOfData',['../classemakefun_1_1_color_sensor.html#a37a8d07c0d1c694de4700004660b0271a2d87d87bc3a7c7b34fe6c858224aa8cf',1,'emakefun::ColorSensor']]],
  ['ki2ctimeout_4',['kI2cTimeout',['../classemakefun_1_1_color_sensor.html#a37a8d07c0d1c694de4700004660b0271a8ffc83e05ce9de7aa8d6c63afe0dd4ed',1,'emakefun::ColorSensor']]],
  ['kinvalidparameter_5',['kInvalidParameter',['../classemakefun_1_1_color_sensor.html#a37a8d07c0d1c694de4700004660b0271a479c1e789b73e2040e6e6efdd184b6d5',1,'emakefun::ColorSensor']]],
  ['kok_6',['kOK',['../classemakefun_1_1_color_sensor.html#a37a8d07c0d1c694de4700004660b0271afd3e293f52487a90a3e3054f8ddc93a0',1,'emakefun::ColorSensor']]],
  ['kunknownerror_7',['kUnknownError',['../classemakefun_1_1_color_sensor.html#a37a8d07c0d1c694de4700004660b0271a643f5ef1f70a601ab9db9736c0af4d3a',1,'emakefun::ColorSensor']]]
];
