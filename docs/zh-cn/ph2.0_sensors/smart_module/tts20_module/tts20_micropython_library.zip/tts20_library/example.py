import time

import tts20

tts = tts20.TTS20(2, 3, 0x40)


tts.play("[v5]" + str("你好"))
while not (not tts.is_busy()):
    time.sleep_ms(100)
tts.play("[n2]" + str(12345))
while not (not tts.is_busy()):
    time.sleep_ms(100)
tts.stop()
