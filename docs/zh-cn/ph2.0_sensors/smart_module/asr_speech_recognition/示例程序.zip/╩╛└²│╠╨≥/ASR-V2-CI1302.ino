#include <Arduino.h>

// 硬件串口定义：使用 ESP32 的 UART1
// 根据你的描述和代码：
// ESP32 GPIO13 (RX) <- 接 CI1303 的 TXD
// ESP32 GPIO12 (TX) -> 接 CI1303 的 RXD
HardwareSerial myserial(1); 

// 串口接收状态机变量
uint8_t rx_state = 0;
uint8_t rx_buf[5] = {0}; 

// 定义协议结构体，用于快速查表
struct VoiceCommand {
  uint8_t category; // 类别 (例如 0x00 是命令词, 0x01 是欢迎语, 0xFF 是播报语)
  uint8_t cmd_id;   // 指令ID (例如 0x01)
  const char* text; // 播报的内容
};

// 常用指令映射表（你可以根据 Excel 继续往下添加）
// 数据来源：5.1.2 命令词播报词协议列表.xlsx
const VoiceCommand cmd_table[] = {
  // --- 系统控制类 (类别 0x01, 0x02, 0x03) ---
  {0x01, 0x00, "正在播报：欢迎使用小慧"},         // 欢迎语 AA 55 01 00 FB
  {0x02, 0x00, "正在播报：我去休息啦"},           // 休息语 AA 55 02 00 FB
  {0x03, 0x00, "正在播报：我在"},                 // 唤醒词 AA 55 03 00 FB
  
  // --- 命令词 (类别 0x00) ---
  {0x00, 0x01, "正在播报：正在前进"},             // AA 55 00 01 FB
  {0x00, 0x02, "正在播报：正在后退"},             // AA 55 00 02 FB
  {0x00, 0x03, "正在播报：正在左转"},             // AA 55 00 03 FB
  {0x00, 0x04, "正在播报：正在右转"},             // AA 55 00 04 FB
  {0x00, 0x09, "正在播报：收到 (停止/停下)"},     // AA 55 00 09 FB
  {0x00, 0x12, "正在播报：灯已开"},               // AA 55 00 12 FB
  {0x00, 0x13, "正在播报：灯已关"},               // AA 55 00 13 FB
  {0x00, 0x6C, "正在播报：收到 (跳舞)"},          // AA 55 00 6C FB
  
  // --- 播报语 (类别 0xFF) ---
  {0xFF, 0x01, "正在播报：可回收物"},             // AA 55 FF 01 FB
  {0xFF, 0x02, "正在播报：厨余垃圾"},             // AA 55 FF 02 FB
  {0xFF, 0x0F, "正在播报：你好，欢迎光临"},       // AA 55 FF 0F FB
};

void setup() {
  // 初始化与电脑通信的串口 (用于打印显示)
  Serial.begin(115200); 
  
  // 初始化与 CI1303 通信的串口1 (RX:13, TX:12)
  myserial.begin(115200, SERIAL_8N1, 13, 12); 
  
  delay(1000); // 等待串口初始化完成
  Serial.println("=========================================");
  Serial.println("ESP32 已就绪，正在监听 CI1303 语音模块...");
  Serial.println("=========================================");
}

void loop() {
  // 只要串口有数据，就一直读取
  while (myserial.available() > 0) {
    uint8_t byte_in = myserial.read();
    
    // 状态机解析 5 字节协议: AA 55 [类别] [ID] FB
    switch (rx_state) {
      case 0: // 寻找帧头 0xAA
        if (byte_in == 0xAA) {
          rx_buf[0] = byte_in;
          rx_state = 1;
        }
        break;
        
      case 1: // 寻找帧头 0x55
        if (byte_in == 0x55) {
          rx_buf[1] = byte_in;
          rx_state = 2;
        } else {
          rx_state = 0; // 数据错误，重新寻找
        }
        break;
        
      case 2: // 接收类别
        rx_buf[2] = byte_in;
        rx_state = 3;
        break;
        
      case 3: // 接收指令ID
        rx_buf[3] = byte_in;
        rx_state = 4;
        break;
        
      case 4: // 寻找帧尾 0xFB
        if (byte_in == 0xFB) {
          rx_buf[4] = byte_in;
          rx_state = 0; // 一帧接收完毕，重置状态
          
          // 处理接收到的完整数据
          process_command(rx_buf[2], rx_buf[3]);
        } else {
          rx_state = 0; // 帧尾不对，丢弃该包
        }
        break;
    }
  }
}

// 处理并打印接收到的指令
void process_command(uint8_t category, uint8_t cmd_id) {
  // 1. 首先打印原始的十六进制协议，方便调试
  Serial.print("收到数据: AA 55 ");
  if(category < 0x10) Serial.print("0");
  Serial.print(category, HEX);
  Serial.print(" ");
  if(cmd_id < 0x10) Serial.print("0");
  Serial.print(cmd_id, HEX);
  Serial.println(" FB");

  // 2. 在映射表中查找对应的播报内容
  bool found = false;
  int num_commands = sizeof(cmd_table) / sizeof(cmd_table[0]);
  
  for (int i = 0; i < num_commands; i++) {
    if (cmd_table[i].category == category && cmd_table[i].cmd_id == cmd_id) {
      Serial.println(cmd_table[i].text);
      found = true;
      break;
    }
  }
  
  // 3. 如果没找到，提示未知指令
  if (!found) {
    Serial.println("收到未知指令，请在 cmd_table 中添加映射。");
  }
  Serial.println("-------------------------");
}