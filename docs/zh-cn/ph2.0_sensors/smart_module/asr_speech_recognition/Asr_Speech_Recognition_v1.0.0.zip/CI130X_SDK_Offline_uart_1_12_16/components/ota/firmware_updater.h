#ifndef __FIRMWARE_UPDATE_H__
#define __FIRMWARE_UPDATE_H__


/**
  * @功能:主函数，进入应用程序的入口
  * @注意:无
  * @参数:无
  * @返回值:无
  */
int firmware_update_main(uint32_t baudrate);


#endif

