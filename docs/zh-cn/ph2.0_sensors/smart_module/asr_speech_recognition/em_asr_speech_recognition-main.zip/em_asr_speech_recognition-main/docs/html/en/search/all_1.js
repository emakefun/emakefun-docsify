var searchData=
[
  ['kversionmajor_0',['kVersionMajor',['../asr__speech__recognition__lib_8h.html#a1e20b5b3451447e4d12549801c671144',1,'em::asr_speech_recognition_lib']]],
  ['kversionminor_1',['kVersionMinor',['../asr__speech__recognition__lib_8h.html#a75a43d1867dd6b762dfb3f7833bea56e',1,'em::asr_speech_recognition_lib']]],
  ['kversionpatch_2',['kVersionPatch',['../asr__speech__recognition__lib_8h.html#ace72e7d33d17745888fbb8dece9d8599',1,'em::asr_speech_recognition_lib']]]
];
