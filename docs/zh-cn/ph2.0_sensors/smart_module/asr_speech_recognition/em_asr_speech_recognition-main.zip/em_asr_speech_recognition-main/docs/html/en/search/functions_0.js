var searchData=
[
  ['asrspeechrecognition_0',['AsrSpeechRecognition',['../classem_1_1_asr_speech_recognition.html#a491ac6ecaa3a72720640546bee082347',1,'em::AsrSpeechRecognition']]]
];
