var searchData=
[
  ['read_5fprotocol_0',['read_protocol',['../classem_1_1_asr_speech_recognition.html#a1b5f57da91d7829385a91b2ae83e9aab',1,'em::AsrSpeechRecognition']]]
];
