var asr__speech__recognition_8h =
[
    [ "em::AsrSpeechRecognition", "classem_1_1_asr_speech_recognition.html", "classem_1_1_asr_speech_recognition" ],
    [ "ASR_SERIAL_BAUD_RATE", "asr__speech__recognition_8h.html#af88ea9f9e00bcb7d00ae5e3b8c3e32e6", null ]
];