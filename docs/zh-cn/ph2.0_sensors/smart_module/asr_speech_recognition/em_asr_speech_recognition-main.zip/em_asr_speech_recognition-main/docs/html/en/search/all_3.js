var searchData=
[
  ['version_0',['Version',['../asr__speech__recognition__lib_8h.html#a4909c5c2782e02e6896ad539f40a1e6f',1,'em::asr_speech_recognition_lib']]]
];
