#include <Servo.h>
#include <SoftwareSerial.h>

namespace {
constexpr uint8_t kSoftwareSerialRX = 12;
constexpr uint8_t kSoftwareSerialTX = 13;

constexpr uint8_t kServoPin = 4;
constexpr uint8_t kMotorInAPin = 5;
constexpr uint8_t kMotorInBPin = 6;
constexpr uint8_t kLedPin = 3;

SoftwareSerial g_soft_serial(kSoftwareSerialRX, kSoftwareSerialTX);
Servo g_servo;

const String knownCommands[] = {"turn on led", "turn off led", "dc run speed", "servo set angle"};

void SetMotorSpeed(const int16_t speed) {
  if (speed > 255 || speed < -255) {
    Serial.println("Error: Speed must be between -255 and 255");
    return;
  }
  if (speed >= 0) {
    analogWrite(kMotorInAPin, speed);
    analogWrite(kMotorInBPin, 0);
  } else {
    analogWrite(kMotorInAPin, 0);
    analogWrite(kMotorInBPin, -speed);
  }
  Serial.print("Motor speed set to: ");
  Serial.println(speed);
}

void SetServoAngle(const uint8_t angle) {
  if (angle > 180) {
    Serial.println("Error: Angle must be between 0 and 180");
  } else {
    g_servo.write(angle);
    Serial.print("Servo angle set to: ");
    Serial.println(angle);
  }
}

uint8_t StringSimilarity(const String &a, const String &b) {
  uint8_t matches = 0;
  for (uint8_t i = 0; i < min(a.length(), b.length()); i++) {
    if (a.charAt(i) == b.charAt(i)) {
      matches++;
    }
  }
  return matches * 100 / max(a.length(), b.length());
}

void ProcessCommand(const String &command) {
  command.trim();
  command.toLowerCase();

  int16_t best_index = -1;
  uint16_t best_score = 0;

  for (uint16_t i = 0; i < sizeof(knownCommands) / sizeof(knownCommands[0]); i++) {
    if (command.indexOf(knownCommands[i]) != -1) {
      best_index = i;
      break;
    }

    const auto score = StringSimilarity(command, knownCommands[i]);
    if (score > best_score && score > 60) {
      best_score = score;
      best_index = i;
    }
  }

  if (best_index == 0) {  // "turn on led"
    digitalWrite(kLedPin, HIGH);
    Serial.println("LED turned ON");

  } else if (best_index == 1) {  // "turn off led"
    digitalWrite(kLedPin, LOW);
    Serial.println("LED turned OFF");

  } else if (best_index == 2) {  // "dc run speed"
    if (command.lastIndexOf(' ') != -1) {
      SetMotorSpeed(command.substring(command.lastIndexOf(' ') + 1).toInt());
    } else {
      Serial.println("Error: No speed value provided for motor command");
    }

  } else if (best_index == 3) {  // "servo set angle"
    if (command.lastIndexOf(' ') != -1) {
      SetServoAngle(command.substring(command.lastIndexOf(' ') + 1).toInt());
    } else {
      Serial.println("Error: No angle value provided for servo command");
    }
  } else {
    Serial.println("Unknown command");
  }
}
}  // namespace

void setup() {
  Serial.begin(115200);

  g_soft_serial.begin(115200);

  pinMode(kLedPin, OUTPUT);
  digitalWrite(kLedPin, LOW);

  pinMode(kMotorInAPin, OUTPUT);
  pinMode(kMotorInBPin, OUTPUT);

  g_servo.attach(kServoPin);
  g_servo.write(90);

  Serial.println("System ready. Waiting for commands...");
}

void loop() {
  if (g_soft_serial.available() ) {
    String command = g_soft_serial.readStringUntil('\n');
    Serial.println("Received: " + command);
    ProcessCommand(command);
  }
}