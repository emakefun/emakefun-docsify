from QMC5883L import QMC5883L

qmc = QMC5883L()
qmc.read_Temperature()
qmc.heading()
