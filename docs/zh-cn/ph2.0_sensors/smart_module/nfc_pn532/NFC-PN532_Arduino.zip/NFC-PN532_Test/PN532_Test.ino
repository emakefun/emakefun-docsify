/*
 * PN532 I2C 读取 M1 卡 UID
 * 适用：Arduino Uno + PN532 (I2C模式)
 * 库：Adafruit PN532
 */

#include <Wire.h>
#include <Adafruit_PN532.h>

// I2C 连接：IRQ 接 D2，RST 接 D3
#define PN532_IRQ   (2)
#define PN532_RESET (3)

Adafruit_PN532 nfc(PN532_IRQ, PN532_RESET);

void setup() {
  Serial.begin(115200);
  Serial.println("PN532 M1 Card Reader");

  nfc.begin();

  uint32_t versiondata = nfc.getFirmwareVersion();
  if (!versiondata) {
    Serial.println("未找到 PN532 模块，请检查接线和 DIP 开关");
    while (1);
  }

  Serial.print("找到 PN532 芯片，固件版本: ");
  Serial.print((versiondata >> 16) & 0xFF, DEC);
  Serial.print('.');
  Serial.println((versiondata >> 8) & 0xFF, DEC);

  nfc.SAMConfig();
  Serial.println("等待 M1 卡...");
}

void loop() {
  uint8_t uid[7] = {0};
  uint8_t uidLength;

  // 读取 ISO14443A 卡片（M1 卡属于此类）
  boolean success = nfc.readPassiveTargetID(PN532_MIFARE_ISO14443A,
                                             uid, &uidLength, 100);

  if (success) {
    Serial.print("卡片 UID: ");
    for (uint8_t i = 0; i < uidLength; i++) {
      if (uid[i] < 0x10) Serial.print("0");
      Serial.print(uid[i], HEX);
      if (i < uidLength - 1) Serial.print(" ");
    }
    Serial.println();
    delay(1000);  // 避免连续重复读取
  }
}