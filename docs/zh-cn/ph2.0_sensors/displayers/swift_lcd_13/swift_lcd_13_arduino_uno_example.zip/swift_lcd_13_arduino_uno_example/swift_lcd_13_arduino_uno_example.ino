#include <Adafruit_ST7789.h>
#include <SPI.h>

namespace {
constexpr uint8_t kDisplayDcPin = 9;
constexpr uint8_t kDisplayCsPin = 10;

constexpr uint32_t kTextSize = 3;

constexpr uint16_t kScreenWidth = 240;
constexpr uint16_t kScreenHeight = 240;

Adafruit_ST7789 g_display(&SPI, kDisplayCsPin, kDisplayDcPin, -1);

}  // namespace

void setup() {
  SPI.begin();

  g_display.init(kScreenWidth, kScreenHeight);
  g_display.setRotation(2);
  g_display.fillScreen(ST77XX_BLACK);
  g_display.setTextSize(kTextSize);
  g_display.setTextColor(ST77XX_WHITE);
  g_display.print("Hello World!");
}

void loop() {
}