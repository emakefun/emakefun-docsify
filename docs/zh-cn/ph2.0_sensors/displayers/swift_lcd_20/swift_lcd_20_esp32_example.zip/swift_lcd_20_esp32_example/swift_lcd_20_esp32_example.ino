#include <Adafruit_ST7789.h>
#include <SPI.h>

namespace {

constexpr auto kDisplaySclkPin = GPIO_NUM_17;
constexpr auto kDisplayMosiPin = GPIO_NUM_15;
constexpr auto kDisplayDcPin = GPIO_NUM_14;
constexpr auto kDisplayCsPin = GPIO_NUM_12;

constexpr uint32_t kTextSize = 3;

constexpr uint16_t kScreenWidth = 240;
constexpr uint16_t kScreenHeight = 320;

Adafruit_ST7789 g_display(&SPI, kDisplayCsPin, kDisplayDcPin, -1);

}  // namespace

void setup() {
  SPI.begin(kDisplaySclkPin, -1, kDisplayMosiPin, -1);

  g_display.init(kScreenWidth, kScreenHeight);
  g_display.setRotation(2);
  g_display.fillScreen(ST77XX_BLACK);
  g_display.setTextSize(kTextSize);
  g_display.setTextColor(ST77XX_WHITE);
  g_display.print("Hello World!");
}

void loop() {
}