from microbit import *
import mb_i2c_lcd1602

l = mb_i2c_lcd1602.LCD1620()
l.puts("Hello microbit!")
