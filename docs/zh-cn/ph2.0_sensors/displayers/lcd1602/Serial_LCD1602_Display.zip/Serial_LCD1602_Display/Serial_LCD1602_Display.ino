/**********************************************
 * HelloWorld
 * 
 * www.emakefun.com
 **********************************************/

#include "LiquidCrystal_I2C.h"

LiquidCrystal_I2C lcd(0x27, 16, 2);  // 将LCD地址设置为0x27以显示16个字符和2行

void setup()
{
    lcd.init();                      // 初始化液晶
    //在液晶显示屏上打印一条信息.
    lcd.backlight();
    lcd.setCursor(2, 0); // 转到第一行的开头
    lcd.print("Hello, world!");
    lcd.setCursor(4, 1); //转到第二行的开头
    lcd.print("keywis2");
}

void loop()
{
}
