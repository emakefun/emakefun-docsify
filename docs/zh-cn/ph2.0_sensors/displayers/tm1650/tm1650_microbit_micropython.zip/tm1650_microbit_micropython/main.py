from microbit import *
from TM1650 import FourDigitDisplay

i2c.init()
display = FourDigitDisplay()

while True:
    display.shownum(3456)