import machine
import time
from tm1650_four_digit_led import Tm1650FourDigitLed

i2c = machine.I2C(0, sda=21, scl=22)

# Construct and initialize four digit TM1650 display
four_digit_led = Tm1650FourDigitLed(i2c=i2c)

print('run')

while True:
    for pos in range(4):
        four_digit_led.segment_on(pos,
                                  Tm1650FourDigitLed.SEGMENT_A)  # segment A on
        time.sleep_ms(100)
        four_digit_led.segment_on(pos,
                                  Tm1650FourDigitLed.SEGMENT_B)  # segment B on
        time.sleep_ms(100)
        four_digit_led.segment_on(pos,
                                  Tm1650FourDigitLed.SEGMENT_C)  # segment C on
        time.sleep_ms(100)
        four_digit_led.segment_on(pos,
                                  Tm1650FourDigitLed.SEGMENT_D)  # segment D on
        time.sleep_ms(100)
        four_digit_led.segment_on(pos,
                                  Tm1650FourDigitLed.SEGMENT_E)  # segment E on
        time.sleep_ms(100)
        four_digit_led.segment_on(pos,
                                  Tm1650FourDigitLed.SEGMENT_F)  # segment F on
        time.sleep_ms(100)
        four_digit_led.segment_on(pos,
                                  Tm1650FourDigitLed.SEGMENT_G)  # segment G on
        time.sleep_ms(100)
        four_digit_led.segment_on(
            pos, Tm1650FourDigitLed.SEGMENT_DP)  # segment DP on
        time.sleep_ms(100)

    for pos in range(4):
        four_digit_led.segment_off(
            pos, Tm1650FourDigitLed.SEGMENT_A)  # segment A off
        time.sleep_ms(100)
        four_digit_led.segment_off(
            pos, Tm1650FourDigitLed.SEGMENT_B)  # segment B off
        time.sleep_ms(100)
        four_digit_led.segment_off(
            pos, Tm1650FourDigitLed.SEGMENT_C)  # segment C off
        time.sleep_ms(100)
        four_digit_led.segment_off(
            pos, Tm1650FourDigitLed.SEGMENT_D)  # segment D off
        time.sleep_ms(100)
        four_digit_led.segment_off(
            pos, Tm1650FourDigitLed.SEGMENT_E)  # segment E off
        time.sleep_ms(100)
        four_digit_led.segment_off(
            pos, Tm1650FourDigitLed.SEGMENT_F)  # segment F off
        time.sleep_ms(100)
        four_digit_led.segment_off(
            pos, Tm1650FourDigitLed.SEGMENT_G)  # segment G off
        time.sleep_ms(100)
        four_digit_led.segment_off(
            pos, Tm1650FourDigitLed.SEGMENT_DP)  # segment DP off
        time.sleep_ms(100)
