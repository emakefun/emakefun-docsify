import time
import x16k33_four_digit_led

four_digit_led = x16k33_four_digit_led.X16k33FourDigitLed(colon_position=2)

while True:
    # Show digit 0 with decimal point
    four_digit_led.show_digit_number(0, 1, True)
    time.sleep_ms(500)

    # Show digit 1 without decimal point
    four_digit_led.show_digit_number(1, 2, False)
    time.sleep_ms(500)

    # Show more digits individually
    four_digit_led.show_digit_number(2, 3, True)
    time.sleep_ms(500)

    four_digit_led.show_digit_number(3, 4, False)
    time.sleep_ms(500)

    # Show integer number
    four_digit_led.show_number(1234)
    time.sleep_ms(500)

    # Show float number
    four_digit_led.show_number(56.78)
    time.sleep_ms(500)
