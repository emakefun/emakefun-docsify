import microbit


class X16k33():

    DEFAULT_I2C_ADDRESS: int = 0x70

    BLINK_OFF: int = 0
    BLINK_RATE_2_HZ: int = 1
    BLINK_RATE_1_HZ: int = 2
    BLINK_RATE_HALF_HZ: int = 3

    _DISPLAY_ON: int = 0x81
    _DISPLAY_OFF: int = 0x80
    _SYSTEM_ON: int = 0x21
    _SYSTEM_OFF: int = 0x20
    _DISPLAY_ADDRESS: int = 0x00
    _CMD_BRIGHTNESS: int = 0xE0
    _CMD_BLINK: int = 0x81

    def __init__(self, i2c_address=DEFAULT_I2C_ADDRESS):
        self._i2c_address = i2c_address
        self.data = bytearray(16)
        self.clear()
        self.power_on()

    def blink_rate(self, blink_rate: int) -> None:
        microbit.i2c.write(self._i2c_address,
                           bytes([X16k33._CMD_BLINK | (blink_rate << 1)]))

    def brightness(self, brightness: int) -> None:
        microbit.i2c.write(self._i2c_address,
                           bytes([X16k33._CMD_BRIGHTNESS | brightness]))

    def power_on(self) -> None:
        microbit.i2c.write(self._i2c_address, bytes([X16k33._SYSTEM_ON]))
        microbit.i2c.write(self._i2c_address, bytes([X16k33._DISPLAY_ON]))

    def power_off(self) -> None:
        microbit.i2c.write(self._i2c_address, bytes([X16k33._DISPLAY_OFF]))
        microbit.i2c.write(self._i2c_address, bytes([X16k33._SYSTEM_OFF]))

    def clear(self) -> None:
        for i in range(len(self.data)):
            self.data[i] = 0x00
        microbit.i2c.write(self._i2c_address,
                           bytes([X16k33._DISPLAY_ADDRESS]) + self.data)

    def __setitem__(self, position: int, value: int) -> None:
        self.data[position] = value

    def write(self) -> None:
        microbit.i2c.write(self._i2c_address,
                           bytes([X16k33._DISPLAY_ADDRESS]) + self.data)
