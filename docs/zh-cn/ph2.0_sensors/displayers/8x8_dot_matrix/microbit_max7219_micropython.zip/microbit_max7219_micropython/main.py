from max7219 import Matrix8x8
from microbit import *

# slck = pin13, mosi = pin15, miso = pin14
matrix_8x32 = Matrix8x8(cs=pin12,num=1)
matrix_8x32.brightness(15)
print('start')

while True:
    matrix_8x32.show(12345)
    sleep(500)

    matrix_8x32.show(98.7)
    sleep(500)

    matrix_8x32.show("abcd")
    sleep(500)

    matrix_8x32.clear()
    sleep(500)

