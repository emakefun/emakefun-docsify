from micropython import const
from micropython import framebuf
from microbit import *


class Matrix8x8:
    _NOOP = const(0)
    _DIGIT0 = const(1)
    _DECODEMODE = const(9)
    _INTENSITY = const(10)
    _SCANLIMIT = const(11)
    _SHUTDOWN = const(12)
    _DISPLAYTEST = const(15)

    def __init__(self, cs, num):
        spi.init(slck = pin13, mosi = pin15, miso = pin14)
        self._cs = cs
        self._cs.write_digital(1)
        self._buffer = bytearray(8 * num)
        self._num = num
        self._frame_buffer = framebuf.FrameBuffer(self._buffer, 8 * num, 8,
                                                  framebuf.MONO_HLSB)
        # Provide methods for accessing FrameBuffer graphics primitives. This is a workround
        # because inheritance from a native class is currently unsupported.
        # http://docs.micropython.org/en/latest/pyboard/library/framebuf.html
        self.fill = self._frame_buffer.fill  # (col)
        self.pixel = self._frame_buffer.pixel  # (x, y[, c])
        self.hline = self._frame_buffer.hline  # (x, y, w, col)
        self.vline = self._frame_buffer.vline  # (x, y, h, col)
        self.line = self._frame_buffer.line  # (x1, y1, x2, y2, col)
        self.rect = self._frame_buffer.rect  # (x, y, w, h, col)
        self.fill_rect = self._frame_buffer.fill_rect  # (x, y, w, h, col)
        self.text = self._frame_buffer.text  # (string, x, y, col=1)
        self.scroll = self._frame_buffer.scroll  # (dx, dy)
        self.blit = self._frame_buffer.blit  # (fbuf, x, y[, key])
        self._scrolling_frame_buffer = None
        self._last_scrolling_step_time = None
        self._scrolling_step = 0
        self._max_scrolling_step = 0
        self._column_scroll_interval_ms = 0
        self.init()

    def _write(self, command, data):
        self._cs.write_digital(0)
        for _ in range(self._num):
            spi.write(bytearray([command, data]))
        self._cs.write_digital(1)

    def init(self):
        for command, data in (
            (Matrix8x8._SHUTDOWN, 0),
            (Matrix8x8._DISPLAYTEST, 0),
            (Matrix8x8._SCANLIMIT, 7),
            (Matrix8x8._DECODEMODE, 0),
            (Matrix8x8._SHUTDOWN, 1),
        ):
            self._write(command, data)

    def brightness(self, value):
        if not 0 <= value <= 15:
            raise ValueError("Brightness out of range")
        self._write(Matrix8x8._INTENSITY, value)

    def write(self):
        for y in range(8):
            self._cs.write_digital(0)
            for m in range(self._num - 1, -1, -1):
                spi.write(
                    bytearray([
                        Matrix8x8._DIGIT0 + y, self._buffer[(y * self._num) + m]
                    ]))
            self._cs.write_digital(1)

    def show(self, value, column_scroll_interval_ms=0):
        if not isinstance(value, str):
            value = str(value)

        if column_scroll_interval_ms > 0:
            self._frame_buffer.fill(0)
            self.write()
            value = ' ' * self._num + value
            self._scrolling_frame_buffer = framebuf.FrameBuffer(
                bytearray(8 * len(value)), 8 * len(value), 8,
                framebuf.MONO_HLSB)
            self._scrolling_frame_buffer.text(value, 0, 0)
            self._last_scrolling_step_time = None
            self._scrolling_step = 0
            self._max_scrolling_step = len(value) * 8
            self._column_scroll_interval_ms = column_scroll_interval_ms
        else:
            self._scrolling_frame_buffer = None
            self._frame_buffer.fill(0)
            self._frame_buffer.text(value[0:self._num], 0, 0)
            self.write()

    def tick(self):
        if self._scrolling_frame_buffer is None:
            return

        if self._last_scrolling_step_time is not None and running_time()(
        ) - self._last_scrolling_step_time < self._column_scroll_interval_ms:
            return

        self._last_scrolling_step_time = running_time()

        self._frame_buffer.fill(0)
        self._frame_buffer.blit(self._scrolling_frame_buffer,
                                -self._scrolling_step, 0)
        self.write()
        self._scrolling_step += 1

        if self._scrolling_step > self._max_scrolling_step:
            self._scrolling_frame_buffer = None

    def scrolling_completed(self):
        return self._scrolling_frame_buffer is None

    def clear(self):
        self._scrolling_frame_buffer = None
        self._frame_buffer.fill(0)
        self.write()
