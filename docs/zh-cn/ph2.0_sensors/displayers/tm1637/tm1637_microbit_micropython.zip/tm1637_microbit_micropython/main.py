from microbit import *
from tm1637 import TM1637
tm = TM1637(clk=pin14, dio=pin15)

# Display 13:00
tm.numbers(13, 00)
sleep(1000)
tm.clear()
