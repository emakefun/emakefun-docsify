from machine import Pin
import tm1637

smg = tm1637.TM1637(clk=Pin(18), dio=Pin(19))


def main():
    smg.show("    ")  # 四个空格，清屏
    # smg.hex(10)  #十六进制A
    # smg.number(1234)  # 显示数字，范围0-9999
    # smg.numbers(11,56,1) # 时间显示，传递2个数值，最后一位1是点亮0是灭
    # smg.temperature(22) #温度显示
    # smg.show("2  9") # 输入空格则不显示，可用于清屏
    # smg.show("{}   ".format(8))
    # smg.show(" %.2d"%6) #显示06
    smg.scroll("0123 4567  89")  # 向左滚动显示


if __name__ == "__main__":
    main()
