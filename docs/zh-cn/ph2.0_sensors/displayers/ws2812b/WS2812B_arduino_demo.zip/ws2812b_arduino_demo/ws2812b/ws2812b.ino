#include "rgb_led.h"  // 引入 RGB 灯的库

namespace {
constexpr uint8_t kRgbPin = 6;  // 定义 RGB 信号引脚

constexpr uint8_t kRgbNum = 12;  // 设置 RGB 灯环或灯带的灯珠个数

RGBLed g_rgb(kRgbPin, kRgbNum);  // 初始化灯带或灯环
}  // namespace

void setup() {
  g_rgb.setBrightness(50);  // 设置灯珠的亮度
}

void loop() {
  for (uint8_t i = 0; i < kRgbNum; i++) {  // 通过 for 循环点亮每一个灯珠
    // 设置灯珠的颜色：参数依次为灯珠序号、红色 R 值、绿色 G 值、蓝色 B 值
    g_rgb.setColorAt(i, 255, 255, 0);
    delay(50);     // 延时 50ms 点亮下一个灯珠
    g_rgb.show();  // 点亮灯珠
  }
}