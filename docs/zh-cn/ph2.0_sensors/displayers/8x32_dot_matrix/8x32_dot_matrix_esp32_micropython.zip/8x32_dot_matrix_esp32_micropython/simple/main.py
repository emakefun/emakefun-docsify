import machine
import max7219
import time

spi = machine.SPI(1, sck=27, mosi=25)

matrix_8x32 = max7219.Matrix8x8(spi=spi,
                                cs=machine.Pin(26, machine.Pin.OUT),
                                num=4)
matrix_8x32.brightness(15)
print('start')

while True:
    matrix_8x32.show(12345)
    time.sleep_ms(500)

    matrix_8x32.show(98.7)
    time.sleep_ms(500)

    matrix_8x32.show("abcd")
    time.sleep_ms(500)

    matrix_8x32.clear()
    time.sleep_ms(500)

