import machine
import max7219

spi = machine.SPI(1, sck=27, mosi=25)

matrix_8x32 = max7219.Matrix8x8(spi=spi,
                                cs=machine.Pin(26, machine.Pin.OUT),
                                num=4)
matrix_8x32.brightness(15)
print('start')

while True:
    # tick中会进行滚动显示
    matrix_8x32.tick()

    # scrolling_completed: 判断滚动显示是否完成
    if matrix_8x32.scrolling_completed():

        # 如果滚动显示完成，继续显示
        # column_scroll_interval_ms：滚动显示时间间隔，代表每隔多少ms向左滚动一列，时间越小滚动越快
        matrix_8x32.show(12345, column_scroll_interval_ms=100)
