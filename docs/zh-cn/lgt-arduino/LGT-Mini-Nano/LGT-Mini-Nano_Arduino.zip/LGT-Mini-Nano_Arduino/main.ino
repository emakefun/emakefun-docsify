void setup() {
  // 将 A0 引脚配置为数字输出模式
  pinMode(A0, OUTPUT);
}

void loop() {
  digitalWrite(A0, HIGH);   // A0 输出高电平
  delay(1000);              // 保持 1000 毫秒（1 秒）
  digitalWrite(A0, LOW);    // A0 输出低电平
  delay(1000);              // 保持 1000 毫秒（1 秒）
}